package app.com.example.genc_ahmeti.aktiehq.app;

/**
 * Created by Genc_Ahmeti on 27.01.2018.
 */

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ExpandableListDataPump {

    public static HashMap<String, List<String>> getData(String[][] strArray) {
        HashMap<String, List<String>> expandableListDetail = new HashMap<String, List<String>>();

        List<String> temp;
        for(int n = 0; n < strArray.length; n++)
        {
            temp = new ArrayList<String>();
            for (int i = 1; i < strArray[n].length; i++)
            {
                temp.add(strArray[n][i]);
            }
            expandableListDetail.put(strArray[0][0], temp);
        }

        return expandableListDetail;
    }
}
