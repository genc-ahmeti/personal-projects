package app.com.example.genc_ahmeti.aktiehq.app;

import android.content.Context;
import android.widget.ExpandableListView;

/**
 * Created by Genc_Ahmeti on 27.01.2018.
 */

public class CustomExpandableListView extends ExpandableListView
{
    public CustomExpandableListView(Context context)
    {
        super(context);
    }
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec)
    {
        widthMeasureSpec = MeasureSpec.makeMeasureSpec(960, MeasureSpec.AT_MOST);
        heightMeasureSpec = MeasureSpec.makeMeasureSpec(1600, MeasureSpec.AT_MOST);
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }
}
