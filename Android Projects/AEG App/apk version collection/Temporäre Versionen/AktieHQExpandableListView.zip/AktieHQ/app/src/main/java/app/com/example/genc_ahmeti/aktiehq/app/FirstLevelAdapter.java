package app.com.example.genc_ahmeti.aktiehq.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Genc_Ahmeti on 27.01.2018.
 */

public class FirstLevelAdapter extends BaseExpandableListAdapter {
    private final Context mContext;
    private final ExpandableListView mExpandableListView;
    // 1 = fach, 2 = raum, 3 = klasse
    private final int mAdapterModus;
    private final boolean mIstInDerOberstufe;
    private final int mViewNummer;
    private final List<String> mListDataHeader;
    private final Map<String, List<String>> mListData_SecondLevel_Map;
    private final Map<String, List<String>> mListData_ThirdLevel_Map;
    public FirstLevelAdapter(Context mContext, List<String> mListDataHeader, ExpandableListView expandableListView, int adapterModus, boolean istInDerOberstufe, int viewNummer) {
        this.mIstInDerOberstufe = istInDerOberstufe;
        this.mViewNummer = viewNummer;
        this.mContext = mContext;
        this.mExpandableListView = expandableListView;
        this.mAdapterModus = adapterModus;
        this.mListDataHeader = new ArrayList<>();
        this.mListDataHeader.addAll(mListDataHeader);
        // Init second level data
        String[] mItemHeaders;
        mListData_SecondLevel_Map = new HashMap<>();
        int parentCount = mListDataHeader.size();
        for (int i = 0; i < parentCount; i++) {
            switch(mAdapterModus)
            {
                case 1:
                    if(mIstInDerOberstufe)
                        mItemHeaders = mContext.getResources().getStringArray(R.array.fach_oberstufe);
                else
                        mItemHeaders = mContext.getResources().getStringArray(R.array.fach_mittelunterstufe);
                    break;
                case 2: mItemHeaders = mContext.getResources().getStringArray(R.array.raum); break;
                case 3: mItemHeaders = mContext.getResources().getStringArray(R.array.klasse); break;
                default: mItemHeaders = null;
            }
            mListData_SecondLevel_Map.put(mListDataHeader.get(i), Arrays.asList(mItemHeaders));
        }
        // THIRD LEVEL
        String[] mItemChildOfChild;
        List<String> listChild;
        mListData_ThirdLevel_Map = new HashMap<>();
        for (Object o : mListData_SecondLevel_Map.entrySet()) {
            Map.Entry entry = (Map.Entry) o;
            Object object = entry.getValue();
            if (object instanceof List) {
                List<String> stringList = new ArrayList<>();
                Collections.addAll(stringList, (String[]) ((List) object).toArray());
                for (int i = 0; i < stringList.size(); i++) {
                    String a = stringList.get(i);
                    switch(mAdapterModus) {
                        case 1:
                       if(mIstInDerOberstufe) {
                           switch (stringList.get(i)) {
                               case "D":
                                   mItemChildOfChild = mContext.getResources().getStringArray(R.array.fach_oberstufe_D);
                                   break;
                               case "M":
                                   mItemChildOfChild = mContext.getResources().getStringArray(R.array.fach_oberstufe_M);
                                   break;
                               case "E":
                                   mItemChildOfChild = mContext.getResources().getStringArray(R.array.fach_oberstufe_E);
                                   break;
                               case "F":
                                   mItemChildOfChild = mContext.getResources().getStringArray(R.array.fach_oberstufe_F);
                                   break;
                               case "Ph":
                                   mItemChildOfChild = mContext.getResources().getStringArray(R.array.fach_oberstufe_Ph);
                                   break;
                               case "ph":
                                   mItemChildOfChild = mContext.getResources().getStringArray(R.array.fach_oberstufe_ph);
                                   break;
                               case "Ch":
                                   mItemChildOfChild = mContext.getResources().getStringArray(R.array.fach_oberstufe_Ch);
                                   break;
                               case "ch":
                                   mItemChildOfChild = mContext.getResources().getStringArray(R.array.fach_oberstufe_ch);
                                   break;
                               case "G":
                                   mItemChildOfChild = mContext.getResources().getStringArray(R.array.fach_oberstufe_G);
                                   break;
                               case "g":
                                   mItemChildOfChild = mContext.getResources().getStringArray(R.array.fach_oberstufe_g);
                                   break;
                               case "Ek":
                                   mItemChildOfChild = mContext.getResources().getStringArray(R.array.fach_oberstufe_Ek);
                                   break;
                               case "ek":
                                   mItemChildOfChild = mContext.getResources().getStringArray(R.array.fach_oberstufe_ek);
                                   break;
                               case "Bk":
                                   mItemChildOfChild = mContext.getResources().getStringArray(R.array.fach_oberstufe_Bk);
                                   break;
                               case "bk":
                                   mItemChildOfChild = mContext.getResources().getStringArray(R.array.fach_oberstufe_bk);
                                   break;
                               case "eth":
                                   mItemChildOfChild = mContext.getResources().getStringArray(R.array.fach_oberstufe_eth);
                                   break;
                               case "kRel":
                                   mItemChildOfChild = mContext.getResources().getStringArray(R.array.fach_oberstufe_kRel);
                                   break;
                               case "S":
                                   mItemChildOfChild = mContext.getResources().getStringArray(R.array.fach_oberstufe_S);
                                   break;
                               case "s":
                                   mItemChildOfChild = mContext.getResources().getStringArray(R.array.fach_oberstufe_s);
                                   break;
                               case "inf":
                                   mItemChildOfChild = mContext.getResources().getStringArray(R.array.fach_oberstufe_inf);
                                   break;
                               case "vkm":
                                   mItemChildOfChild = mContext.getResources().getStringArray(R.array.fach_oberstufe_vkm);
                                   break;
                               default:
                                   mItemChildOfChild = null;
                           }
                       }
                       else
                       {
                           mItemChildOfChild = new String[]{""};
                       }
                        break;
                        case 2:
                            switch (stringList.get(i)) {
                                case "000":
                                    mItemChildOfChild = mContext.getResources().getStringArray(R.array.raum_000);
                                    break;
                                case "100":
                                    mItemChildOfChild = mContext.getResources().getStringArray(R.array.raum_100);
                                    break;
                                case "200":
                                    mItemChildOfChild = mContext.getResources().getStringArray(R.array.raum_200);
                                    break;
                                case "300":
                                    mItemChildOfChild = mContext.getResources().getStringArray(R.array.raum_300);
                                    break;
                                case "ch":
                                    mItemChildOfChild = mContext.getResources().getStringArray(R.array.raum_ch);
                                    break;
                                case "ph":
                                    mItemChildOfChild = mContext.getResources().getStringArray(R.array.raum_ph);
                                    break;
                                case "bio":
                                    mItemChildOfChild = mContext.getResources().getStringArray(R.array.raum_bio);
                                    break;
                                case "bk":
                                    mItemChildOfChild = mContext.getResources().getStringArray(R.array.raum_bk);
                                    break;
                                case "com":
                                    mItemChildOfChild = mContext.getResources().getStringArray(R.array.raum_com);
                                    break;
                                case "s":
                                    mItemChildOfChild = mContext.getResources().getStringArray(R.array.raum_s);
                                    break;
                                case "N":
                                    mItemChildOfChild = mContext.getResources().getStringArray(R.array.raum_N);
                                    break;
                                default:
                                    mItemChildOfChild = null;
                            }
                            break;
                        case 3:
                            switch (stringList.get(i)) {
                                case "5":
                                    mItemChildOfChild = mContext.getResources().getStringArray(R.array.klasse_mittelunterstufe);
                                    break;
                                case "6":
                                    mItemChildOfChild = mContext.getResources().getStringArray(R.array.klasse_mittelunterstufe);
                                    break;
                                case "7":
                                    mItemChildOfChild = mContext.getResources().getStringArray(R.array.klasse_mittelunterstufe);
                                    break;
                                case "8":
                                    mItemChildOfChild = mContext.getResources().getStringArray(R.array.klasse_mittelunterstufe);
                                    break;
                                case "9":
                                    mItemChildOfChild = mContext.getResources().getStringArray(R.array.klasse_mittelunterstufe);
                                    break;
                                case "10":
                                    mItemChildOfChild = mContext.getResources().getStringArray(R.array.klasse_mittelunterstufe);
                                    break;
                                case "11":
                                    mItemChildOfChild = mContext.getResources().getStringArray(R.array.klasse_oberstufe);
                                    break;
                                case "12":
                                    mItemChildOfChild = mContext.getResources().getStringArray(R.array.klasse_oberstufe);
                                    break;
                                default: mItemChildOfChild = null;
                            }
                            break;
                        default: mItemChildOfChild = null;
                    }
                    listChild = Arrays.asList(mItemChildOfChild);
                    mListData_ThirdLevel_Map.put(stringList.get(i), listChild);
                }
            }
        }
    }
    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return childPosition;
    }
    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }
    @Override
    public View getChildView(int groupPosition, int childPosition,
                             boolean isLastChild, View convertView, ViewGroup parent) {
        final CustomExpandableListView secondLevelExpListView = new CustomExpandableListView(this.mContext);
        String parentNode = (String) getGroup(groupPosition);
        secondLevelExpListView.setAdapter(new SecondLevelAdapter(this.mContext, mListData_SecondLevel_Map.get(parentNode), mListData_ThirdLevel_Map, mExpandableListView));
        secondLevelExpListView.setGroupIndicator(null);
        secondLevelExpListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {

            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id)
            {
                String selectedText = ((TextView) v).getText().toString();
                switch(mAdapterModus) {
                    case 1:
                        MainActivity.setFachViewsAuswahl(selectedText, mViewNummer);
                        break;
                    case 2:
                        MainActivity.setRaumViewsAuswahl(selectedText, mViewNummer);
                        break;
                    case 3:
                        MainActivity.setKlasseViewAuswahl(selectedText);
                        if (MainActivity.getListenerNochNieGestartet())
                            MainActivity.setListenerNochNieGestartet(false);
                        else {

                            MainActivity.setVorherIstInDerOberstufe(MainActivity.getAktuellIstInDerOberstufe());
                            String wochentag = MainActivity.tagImSpinner();
                            for (int stunde = 0; stunde < 11; stunde++)
                                MainActivity.setStundenplan(MainActivity.getWochentagAusString(wochentag.substring(0, 2)), stunde, MainActivity.getFachViewsAuswahl(stunde) + ", " + MainActivity.getRaumViewsAuswahl(stunde));
                            String klasseView = selectedText;
                            if (klasseView.equals(mContext.getResources().getString(R.string.klasse_auswahl)))
                                MainActivity.setAktuellIstInDerOberstufe(false);
                            else if (Integer.parseInt(klasseView.substring(0, klasseView.indexOf(','))) < 11)
                                MainActivity.setAktuellIstInDerOberstufe(false);
                            else
                                MainActivity.setAktuellIstInDerOberstufe(true);

                            for (int n = 0; n < 11; n++) {
                                List<String> listDataHeader = new ArrayList<>();
                                String[] mItemHeaders = new String[]{MainActivity.getFachViewsAuswahl(n)};
                                Collections.addAll(listDataHeader, mItemHeaders);
                                MainActivity.getFachViews()[n].setAdapter(new FirstLevelAdapter(mContext, listDataHeader, MainActivity.getFachViews()[n], 1, MainActivity.getAktuellIstInDerOberstufe(), n));
                            }
                            for (int stunde = 0; stunde < 11; stunde++) {
                                if (MainActivity.getStundenplan(MainActivity.getWochentagAusString(wochentag.substring(0, 2)), stunde) != null) {
                                    if (MainActivity.getVorherIstInDerOberstufe() == MainActivity.getAktuellIstInDerOberstufe()) {
                                        List<String> listDataHeader = new ArrayList<>();
                                        String[] mItemHeaders = new String[]{MainActivity.getStundenplan(MainActivity.getWochentagAusString(wochentag.substring(0, 2)), stunde).substring(0, MainActivity.getStundenplan(MainActivity.getWochentagAusString(wochentag.substring(0, 2)), stunde).indexOf(','))};
                                        Collections.addAll(listDataHeader, mItemHeaders);
                                        MainActivity.getFachViews()[stunde].setAdapter(new FirstLevelAdapter(mContext, listDataHeader, MainActivity.getFachViews()[stunde], 1, MainActivity.getAktuellIstInDerOberstufe(), stunde));
                                    } else {
                                        List<String> listDataHeader = new ArrayList<>();
                                        String[] mItemHeaders = new String[]{mContext.getResources().getString(R.string.fach_auswahl)};
                                        Collections.addAll(listDataHeader, mItemHeaders);
                                        MainActivity.getFachViews()[stunde].setAdapter(new FirstLevelAdapter(mContext, listDataHeader, MainActivity.getFachViews()[stunde], 1, MainActivity.getAktuellIstInDerOberstufe(), stunde));

                                    }

                                    if (MainActivity.getStundenplan(MainActivity.getWochentagAusString(wochentag.substring(0, 2)), stunde).indexOf(',') + 1 == MainActivity.getStundenplan(MainActivity.getWochentagAusString(wochentag.substring(0, 2)), stunde).length() - 1) {
                                        List<String> listDataHeader = new ArrayList<>();
                                        String[] mItemHeaders = new String[]{""};
                                        Collections.addAll(listDataHeader, mItemHeaders);
                                        MainActivity.getRaumViews()[stunde].setAdapter(new FirstLevelAdapter(mContext, listDataHeader, MainActivity.getRaumViews()[stunde], 2, MainActivity.getAktuellIstInDerOberstufe(), stunde));

                                    } else {
                                        List<String> listDataHeader = new ArrayList<>();
                                        String[] mItemHeaders = new String[]{MainActivity.getStundenplan(MainActivity.getWochentagAusString(wochentag.substring(0, 2)), stunde).substring(MainActivity.getStundenplan(MainActivity.getWochentagAusString(wochentag.substring(0, 2)), stunde).indexOf(',') + 2)};
                                        Collections.addAll(listDataHeader, mItemHeaders);
                                        MainActivity.getRaumViews()[stunde].setAdapter(new FirstLevelAdapter(mContext, listDataHeader, MainActivity.getRaumViews()[stunde], 2, MainActivity.getAktuellIstInDerOberstufe(), stunde));
                                    }
                                } else {
                                    List<String> listDataHeader = new ArrayList<>();
                                    String[] mItemHeaders = new String[]{mContext.getResources().getString(R.string.fach_auswahl)};
                                    Collections.addAll(listDataHeader, mItemHeaders);
                                    MainActivity.getFachViews()[stunde].setAdapter(new FirstLevelAdapter(mContext, listDataHeader, MainActivity.getFachViews()[stunde], 1, MainActivity.getAktuellIstInDerOberstufe(), stunde));


                                    listDataHeader = new ArrayList<>();
                                    mItemHeaders = new String[]{mContext.getResources().getString(R.string.raum_auswahl)};
                                    Collections.addAll(listDataHeader, mItemHeaders);
                                    MainActivity.getRaumViews()[stunde].setAdapter(new FirstLevelAdapter(mContext, listDataHeader, MainActivity.getRaumViews()[stunde], 2, MainActivity.getAktuellIstInDerOberstufe(), stunde));
                                }
                            }

                        }
                        break;
                }
                List<String> listDataHeader = new ArrayList<>();
                String[] mItemHeaders = new String[]{selectedText};
                Collections.addAll(listDataHeader, mItemHeaders);
                if (mExpandableListView != null) {
                    FirstLevelAdapter parentLevelAdapter = new FirstLevelAdapter(mContext, listDataHeader, mExpandableListView, mAdapterModus,mIstInDerOberstufe,mViewNummer);
                    mExpandableListView.setAdapter(parentLevelAdapter);
                }
                return false;
            }
        });
        return secondLevelExpListView;
    }
    @Override
    public int getChildrenCount(int groupPosition) {
        return 1;
    }
    @Override
    public Object getGroup(int groupPosition) {
        return this.mListDataHeader.get(groupPosition);
    }
    @Override
    public int getGroupCount() {
        return this.mListDataHeader.size();
    }
    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }
    @Override
    public View getGroupView(int groupPosition, boolean isExpanded,
                             View convertView, ViewGroup parent) {
        String headerTitle = (String) getGroup(groupPosition);
        if (convertView == null) {
            LayoutInflater layoutInflater = (LayoutInflater) this.mContext
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.list_level_1, parent, false);
        }
        TextView lblListHeader = (TextView) convertView
                .findViewById(R.id.listTitle);
        lblListHeader.setTypeface(null, Typeface.BOLD);
        lblListHeader.setTextColor(Color.CYAN);
        lblListHeader.setText(headerTitle);
        return convertView;
    }
    @Override
    public boolean hasStableIds() {
        return true;
    }
    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    } }
