package app.com.example.genc_ahmeti.aktiehq.app;

        import android.app.AlertDialog;
        import android.content.Context;
        import android.content.DialogInterface;
        import android.content.Intent;
        import android.os.AsyncTask;
        import org.jsoup.Connection;
        import org.jsoup.Jsoup;

/**
 * Created by Genc_Ahmeti on 07.05.2017.
 */

public class MoodleAnmelden {// extends AsyncTask<String, Void, String> {
/*
    Context context = null;
    public MoodleAnmelden(Context con)
    {context = con;}
    //protected Memberfunktionen (für zweiten Thread)
    @Override
    protected String doInBackground(String... params) {
        String webURL = params[0];
        String user = params[1];
        String pass = params[2];

          try
       {
            Connection.Response res = Jsoup
                    .connect(webURL)
                    .data("username", user, "password", pass)
                    .method(Connection.Method.POST)
                    .execute();
            MoodleLogin.setLoginCookies(res.cookies());
        }
        catch(Exception e) {
            AlertDialog alertDialog = new AlertDialog.Builder(context).create();
            alertDialog.setMessage("Fehler mit Server. Bitte später nochmal probieren!");
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            alertDialog.show();
        }

        return "ok";
    }

    @Override
    protected void onPostExecute(String result) {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
            alertDialog.setMessage(result);
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            alertDialog.show();
        Intent myIntent = null;
        myIntent = new Intent(context, MoodleLogin.class);
        if (myIntent != null)
            context.startActivity(myIntent);
            }*/
        }

