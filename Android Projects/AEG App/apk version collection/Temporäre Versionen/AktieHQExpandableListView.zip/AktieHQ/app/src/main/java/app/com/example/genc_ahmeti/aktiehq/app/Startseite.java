package app.com.example.genc_ahmeti.aktiehq.app;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.view.View;
import android.content.Intent;
import org.joda.time.DateTime;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import org.apache.commons.lang3.ObjectUtils;

import java.io.IOException;

/**
 * Created by Genc_Ahmeti on 30.12.2017.
 */

public class Startseite extends ListActivity{
String[] überschriften = {"Mein Stundenplan", "Tagesablauf", "Moodle", "News", "Mensa"};
@Override
        protected void onCreate(Bundle savedInstanceState)
{
            super.onCreate(savedInstanceState);
            setContentView(R.layout.startseite_layout);
    ListView listView = getListView();
    ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, überschriften);
    listView.setAdapter(adapter);}

    @Override
            protected void onListItemClick(ListView l, View v, int position, long id)
    {
        Intent myIntent = null;
        switch(position)
        {
            case 0: myIntent = new Intent(Startseite.this, MainActivity.class); break;
            case 1:
                try {
                    MainActivity.getStundenplanFromIS(Startseite.this);
                    MainActivity.getKlasseNameFromIS(Startseite.this);

                    String fehlendeStunde = MainActivity.stundeKorrektEingegeben(Startseite.this);
                    String fehlendeKlasse = MainActivity.klassennameKorrektEingegeben(Startseite.this);
                    if (MainActivity.stundenplanEingegeben(Startseite.this)) {
                        if (fehlendeStunde.equals("")) {
                            if(fehlendeKlasse.equals(""))
                            {MainActivity.wochentagBestimmen();
                            myIntent = new Intent(Startseite.this, Main2Activity.class);}
                            else {
                                AlertDialog alertDialog = new AlertDialog.Builder(Startseite.this).create();
                                alertDialog.setMessage(fehlendeKlasse);
                                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                        new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int which) {
                                                dialog.dismiss();
                                            }
                                        });
                                alertDialog.show();
                            }
                        } else {
                            AlertDialog alertDialog = new AlertDialog.Builder(Startseite.this).create();
                            alertDialog.setMessage(fehlendeStunde);
                            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                        }
                                    });
                            alertDialog.show();
                        }
                    }
                }
                catch(IOException e) {
                    AlertDialog alertDialog = new AlertDialog.Builder(Startseite.this).create();
                    alertDialog.setMessage("Gespeicherter Stundenplan konnte nicht gefunden werden. Bitte neu machen!");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }
                break;
            case 2:
                myIntent = new Intent(Startseite.this, MoodleLogin.class);
                break;
            case 3:
                myIntent = new Intent(Startseite.this, Test.class);
                break;
            default:
        }
        if(myIntent != null)
        startActivity(myIntent);
    }

}

