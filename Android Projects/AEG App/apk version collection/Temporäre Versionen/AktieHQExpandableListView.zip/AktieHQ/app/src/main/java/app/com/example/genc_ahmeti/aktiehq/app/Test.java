package app.com.example.genc_ahmeti.aktiehq.app;

/**
 * Created by Genc_Ahmeti on 19.01.2018.
 */
import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.view.View;
import android.content.Intent;
import org.joda.time.DateTime;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.io.*;
import java.lang.String;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class Test extends AppCompatActivity {

        /*@Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.test_layout);
            // Init top level data
            List<String> listDataHeader = new ArrayList<>();
            String[] mItemHeaders = new String[]{getResources().getString(R.string.fach_auswahl)};
            Collections.addAll(listDataHeader, mItemHeaders);
            ExpandableListView mExpandableListView = (ExpandableListView) findViewById(R.id.expandableListView_Parent);
            if (mExpandableListView != null) {
                FirstLevelAdapter parentLevelAdapter = new FirstLevelAdapter(this, listDataHeader, mExpandableListView, 1,);
                mExpandableListView.setAdapter(parentLevelAdapter);
            }
        }*/

   /* ExpandableListView expandableListView;
    ExpandableListAdapter expandableListAdapter;
    List<String> expandableListTitle;
    HashMap<String, List<String>> expandableListDetail;
    String[][] fächer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_layout);

        fächer = new String[][]{getResources().getStringArray(R.array.fach_oberstufe_D),getResources().getStringArray(R.array.fach_oberstufe_E)};

        expandableListView = (ExpandableListView) findViewById(R.id.expandableListView);
        expandableListDetail = ExpandableListDataPump.getData(fächer);
        expandableListTitle = new ArrayList<String>(expandableListDetail.keySet());
        expandableListAdapter = new CustomExpandableListAdapter(this, expandableListTitle, expandableListDetail);
        expandableListView.setAdapter(expandableListAdapter);
        expandableListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {

            @Override
            public void onGroupExpand(int groupPosition) {
                       // expandableListTitle.set()
            }
        });

        expandableListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {

            @Override
            public void onGroupCollapse(int groupPosition) {
                //expandableListTitle.set

            }
        });

        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v,
                                        int groupPosition, int childPosition, long id) {

                expandableListTitle.set(groupPosition, expandableListDetail.get(expandableListTitle.get(groupPosition)).get(childPosition));
                expandableListDetail.put(expandableListTitle.get(groupPosition), Arrays.asList(fächer[groupPosition]));

                expandableListAdapter = new CustomExpandableListAdapter(Test.this, expandableListTitle, expandableListDetail);
                expandableListView.setAdapter(expandableListAdapter);

                return false;
            }
        });
    }*/

}

