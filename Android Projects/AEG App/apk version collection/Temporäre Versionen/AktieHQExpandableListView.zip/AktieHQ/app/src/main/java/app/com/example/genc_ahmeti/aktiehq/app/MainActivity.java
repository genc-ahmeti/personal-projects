package app.com.example.genc_ahmeti.aktiehq.app;

        import android.content.Context;
        import android.os.Bundle;
        import android.support.v7.app.AppCompatActivity;
        import android.view.Menu;
        import android.view.MenuItem;
        import android.view.MotionEvent;
        import android.view.ViewGroup;
        import android.widget.AdapterView;
        import android.widget.Button;
        import android.view.View;
        import android.content.Intent;
        import org.joda.time.DateTime;
        import android.app.AlertDialog;
        import android.content.DialogInterface;
        import android.widget.ExpandableListView;
        import android.widget.Spinner;
        import android.widget.ArrayAdapter;
        import android.widget.TextView;

        import java.io.*;
        import java.lang.String;
        import java.lang.reflect.Array;
        import java.util.ArrayList;
        import java.util.Collections;
        import java.util.List;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    // erster Index: Wochentag: 0-4 = Mo-Fr
    // zweiter Index: Stunde: 0-10 = 1.-11.
    private static String[][] stundenplan = new String[5][11];

    private static String file = "stundenplanDaten";
    private String wochentagSpinner;
    private String vorherigerWochentagSpinner = "";
    private static ExpandableListView[] fachViews = new ExpandableListView[11];
    private static ExpandableListView[] raumViews = new ExpandableListView[11];
    private ExpandableListView klasseView;
    private static Spinner spinner;
    private static String klasseName;
    private static int[] wochentag = new int[2];
    private Button mBtLaunchActivity;
    private Button etFelderInitialisieren;
    private static boolean aktuellIstInDerOberstufe =false;
    private static boolean vorherIstInDerOberstufe = false;
    private static  String[] fachViewsAuswahl = new String[11];
    private static String[] raumViewsAuswahl = new String[11];
    private static String klasseViewAuswahl;
    private static boolean ListenerNochNieGestartet =false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView[] tvSchulzeiten = new TextView[11];
        for (int n = 0; n < 11; n++) {
            switch (n) {
                case 0:
                    tvSchulzeiten[n] = (TextView) findViewById(R.id.textView9);
                    break;
                case 1:
                    tvSchulzeiten[n] = (TextView) findViewById(R.id.textView10);
                    break;
                case 2:
                    tvSchulzeiten[n] = (TextView) findViewById(R.id.textView12);
                    break;
                case 3:
                    tvSchulzeiten[n] = (TextView) findViewById(R.id.textView13);
                    break;
                case 4:
                    tvSchulzeiten[n] = (TextView) findViewById(R.id.textView15);
                    break;
                case 5:
                    tvSchulzeiten[n] = (TextView) findViewById(R.id.textView16);
                    break;
                case 6:
                    tvSchulzeiten[n] = (TextView) findViewById(R.id.textView18);
                    break;
                case 7:
                    tvSchulzeiten[n] = (TextView) findViewById(R.id.textView19);
                    break;
                case 8:
                    tvSchulzeiten[n] = (TextView) findViewById(R.id.textView20);
                    break;
                case 9:
                    tvSchulzeiten[n] = (TextView) findViewById(R.id.textView21);
                    break;
                case 10:
                    tvSchulzeiten[n] = (TextView) findViewById(R.id.textView22);
                    break;
                default:
            }
        }

        for(int i = 0; i < 11; i++)
        tvSchulzeiten[i].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View viewIn) {
                for(int n = 0; n < 11; n++)
                {
                    if(viewIn == tvSchulzeiten[n])
                    {
                       setViewSelection("",fachViews[n],1, n);
                       setViewSelection("",raumViews[n],2, n);
                       break;
                    }
                }
            }
        });

        klasseView = (ExpandableListView) findViewById(R.id.klasse);
        setViewSelection(getResources().getString(R.string.klasse_auswahl),klasseView,3,0);
        klasseView.setOnTouchListener(new View.OnTouchListener() {
            // Setting on Touch Listener for handling the touch inside ScrollView
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // Disallow the touch request for parent scroll on touch of child view
                v.getParent().requestDisallowInterceptTouchEvent(true);
                return false;
            }
        });

        spinner = (Spinner) findViewById(R.id.wochentage_spinner);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.wochentage_array, android.R.layout.simple_list_item_1);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
 //       spinner.setSelection(adapter.getPosition("Montag"), true);

        wochentagBestimmen();
// Den Klassennamen anzeigen oben links
        try
        {
            getKlasseNameFromIS(MainActivity.this);
            setViewSelection(klasseName,klasseView,3,0);
        }
        catch(IOException e)
        {
            setViewSelection(getResources().getString(R.string.klasse_auswahl),klasseView,3,0);
        }
        for (int n = 0; n < 11; n++) {
            switch (n) {
                case 0:
                    fachViews[n] = (ExpandableListView) findViewById(R.id.fach_views1);
                    fachViews[n].setOnTouchListener(new View.OnTouchListener() {
                        // Setting on Touch Listener for handling the touch inside ScrollView
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            // Disallow the touch request for parent scroll on touch of child view
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            return false;
                        }
                    });
                    break;
                case 1:
                    fachViews[n] = (ExpandableListView) findViewById(R.id.fach_views2);
                    fachViews[n].setOnTouchListener(new View.OnTouchListener() {
                        // Setting on Touch Listener for handling the touch inside ScrollView
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            // Disallow the touch request for parent scroll on touch of child view
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            return false;
                        }
                    });
                    break;
                case 2:
                    fachViews[n] = (ExpandableListView) findViewById(R.id.fach_views3);
                    fachViews[n].setOnTouchListener(new View.OnTouchListener() {
                        // Setting on Touch Listener for handling the touch inside ScrollView
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            // Disallow the touch request for parent scroll on touch of child view
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            return false;
                        }
                    });
                    break;
                case 3:
                    fachViews[n] = (ExpandableListView) findViewById(R.id.fach_views4);

                    fachViews[n].setOnTouchListener(new View.OnTouchListener() {
                        // Setting on Touch Listener for handling the touch inside ScrollView
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            // Disallow the touch request for parent scroll on touch of child view
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            return false;
                        }
                    });
                    break;
                case 4:
                    fachViews[n] = (ExpandableListView) findViewById(R.id.fach_views5);
                    fachViews[n].setOnTouchListener(new View.OnTouchListener() {
                        // Setting on Touch Listener for handling the touch inside ScrollView
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            // Disallow the touch request for parent scroll on touch of child view
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            return false;
                        }
                    });
                    break;
                case 5:
                    fachViews[n] = (ExpandableListView) findViewById(R.id.fach_views6);
                    fachViews[n].setOnTouchListener(new View.OnTouchListener() {
                        // Setting on Touch Listener for handling the touch inside ScrollView
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            // Disallow the touch request for parent scroll on touch of child view
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            return false;
                        }
                    });
                    break;
                case 6:
                    fachViews[n] = (ExpandableListView) findViewById(R.id.fach_views7);
                    fachViews[n].setOnTouchListener(new View.OnTouchListener() {
                        // Setting on Touch Listener for handling the touch inside ScrollView
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            // Disallow the touch request for parent scroll on touch of child view
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            return false;
                        }
                    });
                    break;
                case 7:
                    fachViews[n] = (ExpandableListView) findViewById(R.id.fach_views8);
                    fachViews[n].setOnTouchListener(new View.OnTouchListener() {
                        // Setting on Touch Listener for handling the touch inside ScrollView
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            // Disallow the touch request for parent scroll on touch of child view
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            return false;
                        }
                    });
                    break;
                case 8:
                    fachViews[n] = (ExpandableListView) findViewById(R.id.fach_views9);
                    fachViews[n].setOnTouchListener(new View.OnTouchListener() {
                        // Setting on Touch Listener for handling the touch inside ScrollView
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            // Disallow the touch request for parent scroll on touch of child view
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            return false;
                        }
                    });
                    break;
                case 9:
                    fachViews[n] = (ExpandableListView) findViewById(R.id.fach_views10);
                    fachViews[n].setOnTouchListener(new View.OnTouchListener() {
                        // Setting on Touch Listener for handling the touch inside ScrollView
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            // Disallow the touch request for parent scroll on touch of child view
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            return false;
                        }
                    });
                    break;
                case 10:
                    fachViews[n] = (ExpandableListView) findViewById(R.id.fach_views11);
                    fachViews[n].setOnTouchListener(new View.OnTouchListener() {
                        // Setting on Touch Listener for handling the touch inside ScrollView
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            // Disallow the touch request for parent scroll on touch of child view
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            return false;
                        }
                    });
                    break;
            }
        }

        for (int n = 0; n < 11; n++) {
            switch (n) {
                case 0:
                    raumViews[n] = (ExpandableListView) findViewById(R.id.raum_views1);
                    raumViews[n].setOnTouchListener(new View.OnTouchListener() {
                        // Setting on Touch Listener for handling the touch inside ScrollView
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            // Disallow the touch request for parent scroll on touch of child view
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            return false;
                        }
                    });
                    break;
                case 1:
                    raumViews[n] = (ExpandableListView) findViewById(R.id.raum_views2);
                    raumViews[n].setOnTouchListener(new View.OnTouchListener() {
                        // Setting on Touch Listener for handling the touch inside ScrollView
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            // Disallow the touch request for parent scroll on touch of child view
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            return false;
                        }
                    });
                    break;
                case 2:
                    raumViews[n] = (ExpandableListView) findViewById(R.id.raum_views3);
                    raumViews[n].setOnTouchListener(new View.OnTouchListener() {
                        // Setting on Touch Listener for handling the touch inside ScrollView
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            // Disallow the touch request for parent scroll on touch of child view
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            return false;
                        }
                    });
                    break;
                case 3:
                    raumViews[n] = (ExpandableListView) findViewById(R.id.raum_views4);
                    raumViews[n].setOnTouchListener(new View.OnTouchListener() {
                        // Setting on Touch Listener for handling the touch inside ScrollView
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            // Disallow the touch request for parent scroll on touch of child view
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            return false;
                        }
                    });
                    break;
                case 4:
                    raumViews[n] = (ExpandableListView) findViewById(R.id.raum_views5);
                    raumViews[n].setOnTouchListener(new View.OnTouchListener() {
                        // Setting on Touch Listener for handling the touch inside ScrollView
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            // Disallow the touch request for parent scroll on touch of child view
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            return false;
                        }
                    });
                    break;
                case 5:
                    raumViews[n] = (ExpandableListView) findViewById(R.id.raum_views6);
                    raumViews[n].setOnTouchListener(new View.OnTouchListener() {
                        // Setting on Touch Listener for handling the touch inside ScrollView
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            // Disallow the touch request for parent scroll on touch of child view
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            return false;
                        }
                    });
                    break;
                case 6:
                    raumViews[n] = (ExpandableListView) findViewById(R.id.raum_views7);
                    raumViews[n].setOnTouchListener(new View.OnTouchListener() {
                        // Setting on Touch Listener for handling the touch inside ScrollView
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            // Disallow the touch request for parent scroll on touch of child view
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            return false;
                        }
                    });
                    break;
                case 7:
                    raumViews[n] = (ExpandableListView) findViewById(R.id.raum_views8);
                    raumViews[n].setOnTouchListener(new View.OnTouchListener() {
                        // Setting on Touch Listener for handling the touch inside ScrollView
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            // Disallow the touch request for parent scroll on touch of child view
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            return false;
                        }
                    });
                    break;
                case 8:
                    raumViews[n] = (ExpandableListView) findViewById(R.id.raum_views9);
                    raumViews[n].setOnTouchListener(new View.OnTouchListener() {
                        // Setting on Touch Listener for handling the touch inside ScrollView
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            // Disallow the touch request for parent scroll on touch of child view
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            return false;
                        }
                    });
                    break;
                case 9:
                    raumViews[n] = (ExpandableListView) findViewById(R.id.raum_views10);
                    raumViews[n].setOnTouchListener(new View.OnTouchListener() {
                        // Setting on Touch Listener for handling the touch inside ScrollView
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            // Disallow the touch request for parent scroll on touch of child view
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            return false;
                        }
                    });
                    break;
                case 10:
                    raumViews[n] = (ExpandableListView) findViewById(R.id.raum_views11);
                    raumViews[n].setOnTouchListener(new View.OnTouchListener() {
                        // Setting on Touch Listener for handling the touch inside ScrollView
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            // Disallow the touch request for parent scroll on touch of child view
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            return false;
                        }
                    });
                    break;
            }
        }

    for(int n = 0; n < 11; n++)
        {
            setViewSelection(getResources().getString(R.string.fach_auswahl),fachViews[n],1, n);
            setViewSelection(getResources().getString(R.string.raum_auswahl),raumViews[n],2, n);
        }

        //Wenn im internal Storage schon frühere Stundenpläne vorhanden:
       try
        {
            getStundenplanFromIS(MainActivity.this);
            getKlasseNameFromIS(MainActivity.this);

            String klassenstufe = klasseName.substring(0, klasseName.indexOf(','));

            if(klassenstufe.equals("Klassenstufe") || Integer.parseInt(klassenstufe) < 11)
                aktuellIstInDerOberstufe = false;
            else
                aktuellIstInDerOberstufe = true;

            for(int n = 0; n < 11; n++)
            {
                setViewSelection(getResources().getString(R.string.fach_auswahl),fachViews[n],1, n);
            }
        }
        catch(IOException e)
        {
            aktuellIstInDerOberstufe = false;
            for(int n = 0; n < 11; n++)
            {
                setViewSelection(getResources().getString(R.string.fach_auswahl),fachViews[n],1, n);
                setViewSelection(getResources().getString(R.string.raum_auswahl),raumViews[n],2, n);
            }
            setViewSelection(getResources().getString(R.string.klasse_auswahl),klasseView,3, 0);
            AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
            alertDialog.setMessage("Gespeicherter Stundenplan konnte nicht gefunden werden. Bitte neu machen!");
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            alertDialog.show();
        }

        // Button, um zu den Vertretungen zu kommen
        mBtLaunchActivity = (Button) findViewById(R.id.bt_launch_activity);
        mBtLaunchActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
Intent myIntent = null;
                try {
                    getStundenplanFromIS(MainActivity.this);
                    getKlasseNameFromIS(MainActivity.this);

                    String fehlendeStunde = stundeKorrektEingegeben(MainActivity.this);
                    String fehlendeKlasse = klassennameKorrektEingegeben(MainActivity.this);
                    if (MainActivity.stundenplanEingegeben(MainActivity.this)) {
                        if (fehlendeStunde.equals("")) {
                            if(fehlendeKlasse.equals(""))
                            {MainActivity.wochentagBestimmen();
                                myIntent = new Intent(MainActivity.this, Main2Activity.class);}
                            else {
                                AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
                                alertDialog.setMessage(fehlendeKlasse);
                                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                        new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int which) {
                                                dialog.dismiss();
                                            }
                                        });
                                alertDialog.show();
                            }
                        } else {
                            AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
                            alertDialog.setMessage(fehlendeStunde);
                            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                        }
                                    });
                            alertDialog.show();
                        }
                    }
                }
                catch(IOException e) {
                    AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
                    alertDialog.setMessage("Gespeicherter Stundenplan konnte nicht gefunden werden. Bitte neu machen!");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }
                if(myIntent != null)
                    startActivity(myIntent);
                    }
        });

        // Button, um die Einträge zu speichern
        etFelderInitialisieren = (Button) findViewById(R.id.et_felder_initialisieren);
        etFelderInitialisieren.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                        for(int stunde = 0; stunde < 11; stunde++)
                        {
                            switch(wochentagSpinner.substring(0, 2))
                            {
                                case "Mo": stundenplan[0][stunde] = fachViewsAuswahl[stunde]+", "+raumViewsAuswahl[stunde];
                                    break;
                                case "Di": stundenplan[1][stunde] = fachViewsAuswahl[stunde]+", "+raumViewsAuswahl[stunde];
                                    break;
                                case "Mi": stundenplan[2][stunde] = fachViewsAuswahl[stunde]+", "+raumViewsAuswahl[stunde];
                                    break;
                                case "Do": stundenplan[3][stunde] = fachViewsAuswahl[stunde]+", "+raumViewsAuswahl[stunde];
                                    break;
                                case "Fr": stundenplan[4][stunde] = fachViewsAuswahl[stunde]+", "+raumViewsAuswahl[stunde];
                                    break;
                            }
                        }
                String[][] aa = stundenplan;
                if(stundenplanEingegeben(MainActivity.this))
                {
                // das ist für den Klassennammen
            klasseName = klasseViewAuswahl;
                       try{
                            setKlasseNameInIS();
                        } catch (IOException e) {
                            AlertDialog alertDialog2 = new AlertDialog.Builder(MainActivity.this).create();
                            alertDialog2.setMessage("Klassenname konnte nicht gespeichert werden!");
                            alertDialog2.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                        }
                                    });
                            alertDialog2.show();

                        }

                try {
                        // hier für Fächer und räume des Stundenplans
                        setStundenplanInIS();
                    }
                    catch(IOException e) {
                    AlertDialog alertDialog2 = new AlertDialog.Builder(MainActivity.this).create();
                    alertDialog2.setMessage("Stundenplan konnte nicht gespeichert werden!");
                    alertDialog2.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog2.show();
                }
            }

            }
        });
    }

    public static String getKlasseName()
    {
        return klasseName;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if (id == R.id.action_settings) {

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void launchActivity() {

        Intent intent = new Intent(this, Main2Activity.class);
        startActivity(intent);
    }

    public static String getStundenplan(int wochentag, int stunde)
    {
    return stundenplan[wochentag][stunde];
    }

    public static int getWochentag(int heuteOderMorgen) {
        switch (heuteOderMorgen) {
            case 0:
                return wochentag[0];
            case 1:
                return wochentag[1];
            default:
                return -1;
        }
    }

    public void onItemSelected(AdapterView<?> parent, View view,
                               int pos, long id) {
        // An item was selected. You can retrieve the selected item using
        // parent.getItemAtPosition(pos)
        if (parent == spinner) {
            wochentagSpinner = parent.getItemAtPosition(pos).toString();
            if (vorherigerWochentagSpinner.equals(""))
                vorherigerWochentagSpinner = wochentagSpinner;
            if (!vorherigerWochentagSpinner.equals(wochentagSpinner)) {
                for (int stunde = 0; stunde < 11; stunde++) {
                    stundenplan[getWochentagAusString(vorherigerWochentagSpinner.substring(0, 2))][stunde] = fachViewsAuswahl[stunde] + ", " + raumViewsAuswahl[stunde];

                }
                vorherigerWochentagSpinner = wochentagSpinner;
            }
            String[][] aaa = stundenplan;
            for (int stunde = 0; stunde < 11; stunde++) {
                if (stundenplan[getWochentagAusString(wochentagSpinner.substring(0, 2))][stunde] != null) {
                    if (vorherIstInDerOberstufe == aktuellIstInDerOberstufe)
                        setViewSelection(getStundenplan(getWochentagAusString(wochentagSpinner.substring(0, 2)), stunde).substring(0, getStundenplan(getWochentagAusString(wochentagSpinner.substring(0, 2)), stunde).indexOf(',')), fachViews[stunde], 1, stunde);
                    else
                        setViewSelection(getResources().getString(R.string.fach_auswahl), fachViews[stunde], 1, stunde);

                    if (getStundenplan(getWochentagAusString(wochentagSpinner.substring(0, 2)), stunde).indexOf(',') + 1 == getStundenplan(getWochentagAusString(wochentagSpinner.substring(0, 2)), stunde).length() - 1)
                        setViewSelection("", raumViews[stunde], 2, stunde);
                    else
                        setViewSelection(getStundenplan(getWochentagAusString(wochentagSpinner.substring(0, 2)), stunde).substring(getStundenplan(getWochentagAusString(wochentagSpinner.substring(0, 2)), stunde).indexOf(',') + 2), raumViews[stunde], 2, stunde);
                } else {
                    setViewSelection(getResources().getString(R.string.fach_auswahl), fachViews[stunde], 1, stunde);
                    setViewSelection(getResources().getString(R.string.raum_auswahl), raumViews[stunde], 2, stunde);
                }
            }
            String[][] aa = stundenplan;
        } else {


        }
    }


    public void onNothingSelected(AdapterView<?> parent) {
        // Another interface callback
    }

    public static void getStundenplanFromIS(Context context) throws IOException
    {
        String[][] a = stundenplan;
        FileInputStream fIn = context.openFileInput(file);
        int varMo = 0, varDi = 0, varMi = 0, varDo = 0, varFr = 0;
        String wochentag;
        int c;
        boolean erstesLeerzeichenWarDa = false;
        StringBuilder temp = new StringBuilder("");
        while( (c = fIn.read()) != -1)
        {
            if((char) c != ' ')
                temp.append((char) c);
            if(((char) c == ' ' && erstesLeerzeichenWarDa) || ((char) c == ' ' && !erstesLeerzeichenWarDa) && temp.toString().length() == 3)
            {
                erstesLeerzeichenWarDa = false;
                wochentag = temp.toString().substring(0, 2);
                switch(wochentag)
                {
                    case "Mo":
                        if(temp.toString().length() > 3)
                            stundenplan[0][varMo++] = temp.toString().substring(3);
                        else
                            stundenplan[0][varMo++] = "";
                        break;
                    case "Di": if(temp.toString().length() > 3)
                        stundenplan[1][varDi++] = temp.toString().substring(3);
                    else
                        stundenplan[1][varDi++] = "";
                        break;
                    case "Mi": if(temp.toString().length() > 3)
                        stundenplan[2][varMi++] = temp.toString().substring(3);
                    else
                        stundenplan[2][varMi++] = "";
                        break;
                    case "Do": if(temp.toString().length() > 3)
                        stundenplan[3][varDo++] = temp.toString().substring(3);
                    else
                        stundenplan[3][varDo++] = "";
                        break;
                    case "Fr": if(temp.toString().length() > 3)
                        stundenplan[4][varFr++] = temp.toString().substring(3);
                    else
                        stundenplan[4][varFr++] = "";
                        break;
                }
                temp.setLength(0);
                temp.trimToSize();
                continue;
            }

            if((char) c == ' ' && !erstesLeerzeichenWarDa)
            {
                erstesLeerzeichenWarDa = true;
                temp.append((char) c);
            }


        }
        String[][] aa = stundenplan;
    }

    public void setKlasseNameInIS() throws IOException
    {
        FileOutputStream fOut = openFileOutput("klasseNameIS",MODE_PRIVATE);
        // erst die Klasse
        fOut.write(getKlasseName().getBytes());
    }

    public static void getKlasseNameFromIS(Context context) throws IOException
    {
        FileInputStream fIn = context.openFileInput("klasseNameIS");

        int c;
        StringBuilder temp = new StringBuilder("");
        while( (c = fIn.read()) != -1) {
            temp.append((char) c);
        }
        klasseName = temp.toString();
    }

    public void setStundenplanInIS() throws IOException
    {
        FileOutputStream fOut = openFileOutput(file,MODE_PRIVATE);

        // jetzt kommen die Fächer
        for(int wochentag = 0; wochentag < 5; wochentag++)
            for(int stunde = 0; stunde < 11; stunde++)
            {
                switch(wochentag)
                {
                    case 0: fOut.write("Mo:".getBytes()); break;
                    case 1: fOut.write("Di:".getBytes()); break;
                    case 2: fOut.write("Mi:".getBytes()); break;
                    case 3: fOut.write("Do:".getBytes()); break;
                    case 4: fOut.write("Fr:".getBytes()); break;
                }
                fOut.write((stundenplan[wochentag][stunde] + " ").getBytes());
            }
        fOut.close();
    }

    public static int getWochentagAusString(String wochentagPräfix)
    {
        switch(wochentagPräfix)
        {
            case "Mo":
                return 0;
            case "Di":
                return 1;
            case "Mi":
                return 2;
            case "Do":
                return 3;
            case "Fr":
                return 4;
        }
        return -1;
    }

    public static boolean stundenplanEingegeben(Context context)
    {
        String strWochentag = "";
        for(int wochentag = 0; wochentag < 5; wochentag++)
            for(int stunde = 0; stunde < 11; stunde++)
                if(stundenplan[wochentag][stunde] == null) {
                    switch(wochentag)
                    {
                        case 0:
                            strWochentag += "Montag wurde nicht eingetragen und gespeichert!";
                            break;
                        case 1:
                            strWochentag += "Dienstag wurde nicht eingetragen und gespeichert!";
                            break;
                        case 2:
                            strWochentag += "Mittwoch wurde nicht eingetragen und gespeichert!";
                            break;
                        case 3:
                            strWochentag += "Donnerstag wurde nicht eingetragen und gespeichert!";
                            break;
                        case 4:
                            strWochentag += "Freitag wurde nicht eingetragen und gespeichert!";
                            break;
                    }
                    AlertDialog alertDialog = new AlertDialog.Builder(context).create();
                    alertDialog.setMessage(strWochentag);
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                    return false;
                }
        return true;
    }

    public static void wochentagBestimmen()
    {
        //Bestimmung von heutigem/morgigem Tag bezüglich der Vertretungen
        //wenn samstag, sonntag heute: heuteVertretung:Montag, morgenVertretung:Montag

        //Tag der Woche, von 1-7, Mo-So
        int dayOfWeek = new DateTime().getDayOfWeek();

        if (dayOfWeek == 6 || dayOfWeek == 7) {
            wochentag[0] = 1;
            wochentag[1] = 1;
        } else if (dayOfWeek == 5) {
            wochentag[0] = 5;
            wochentag[1] = 1;
        } else {
            wochentag[0] = dayOfWeek;
            wochentag[1] = wochentag[0] + 1;
        }
    }

    public static String stundeKorrektEingegeben(Context context) {
        String tag = "";
        for(int wochentag = 0; wochentag < 5; wochentag++) {
            switch(wochentag) {
                case 0: tag = "Montag"; break;
                case 1: tag = "Dienstag"; break;
                case 2: tag = "Mittwoch"; break;
                case 3: tag = "Donnerstag"; break;
                case 4: tag = "Freitag"; break;
            }

            for (int stunde = 0; stunde < 11; stunde++) {
                String stunden = stundenplan[wochentag][stunde];
                if(stunden.length() == 2)
                    continue;
               if(stunden.equals(context.getResources().getString(R.string.fach_auswahl) + ", " + context.getResources().getString(R.string.raum_auswahl)))
                   return "Die " + Integer.toString(stunde+1) + ". Stunde am " + tag + "ist gar nicht eingetragen!";
                if((stunden.substring(0, stunden.indexOf(',')).equals(context.getResources().getString(R.string.fach_auswahl))
                        && !stunden.substring(stunden.indexOf(' ')+1).equals(context.getResources().getString(R.string.raum_auswahl)))
                    || (!stunden.substring(0, stunden.indexOf(',')).equals(context.getResources().getString(R.string.fach_auswahl))
                        && stunden.substring(stunden.indexOf(' ')+1).equals(context.getResources().getString(R.string.raum_auswahl))))
                    return "Die " + Integer.toString(stunde+1) + ". Stunde am " + tag + " ist unvollständig eingetragen.";
                if (stundenplan[wochentag][stunde].indexOf(',') == 0 || stundenplan[wochentag][stunde].indexOf(' ') == stundenplan[wochentag][stunde].length()-1)
                    return "Die " + Integer.toString(stunde+1) + ". Stunde am " + tag + " ist unvollständig eingetragen.";
            }
        }
        return "";
    }

    public static String klassennameKorrektEingegeben(Context context)
    {
        if(klasseName.equals(context.getResources().getString(R.string.klasse_auswahl)))
            return "Klassenstufe und Kurs müssen angegeben werden!";
            if (Integer.parseInt(klasseName.substring(0, klasseName.indexOf(','))) > 10 && Character.isLetter(klasseName.charAt(klasseName.length() - 1)))
                return "Die Kurswahl (a-e) ist nicht für die Kursstufe gedacht!";
            if (Integer.parseInt(klasseName.substring(0, klasseName.indexOf(','))) < 11 && Character.isDigit(klasseName.charAt(klasseName.length() - 1)))
                return "Die Kurswahl (1-5) ist nur für die Kursstufe gedacht!";

            return "";
    }

    public void setViewSelection(String text, ExpandableListView eLV, int adapterModus, int viewNummer)
    {
        switch(adapterModus)
        {
            case 1: fachViewsAuswahl[viewNummer] = text; break;
            case 2: raumViewsAuswahl[viewNummer] = text; break;
            case 3: klasseViewAuswahl = text; break;
        }
        List<String> listDataHeader = new ArrayList<>();
        String[] mItemHeaders = new String[]{text};
        Collections.addAll(listDataHeader, mItemHeaders);
        eLV.setAdapter(new FirstLevelAdapter(MainActivity.this, listDataHeader, eLV, adapterModus, aktuellIstInDerOberstufe, viewNummer));
    }

    public static void setFachViewsAuswahl(String auswahl, int viewNummer)
    {
        fachViewsAuswahl[viewNummer] = auswahl;
    }

    public static void setRaumViewsAuswahl(String auswahl, int viewNummer)
    {
        raumViewsAuswahl[viewNummer] = auswahl;
    }

    public static void setKlasseViewAuswahl(String auswahl)
    {
        klasseViewAuswahl= auswahl;
    }

    public static void setListenerNochNieGestartet(boolean bool)
    {
        ListenerNochNieGestartet = bool;
    }

    public static boolean getListenerNochNieGestartet()
    {
        return ListenerNochNieGestartet;
    }

    public static void setAktuellIstInDerOberstufe(boolean bool)
    {
        aktuellIstInDerOberstufe = bool;
    }

    public static boolean getAktuellIstInDerOberstufe()
    {
        return aktuellIstInDerOberstufe;
    }

    public static void setVorherIstInDerOberstufe(boolean bool)
    {
        vorherIstInDerOberstufe = bool;
    }

    public static boolean getVorherIstInDerOberstufe()
    {
        return vorherIstInDerOberstufe;
    }

    public static String tagImSpinner()
    {
        return spinner.getSelectedItem().toString();
    }

    public static void setStundenplan(int wochentag, int stunde, String auswahl)
    {
        stundenplan[wochentag][stunde] = auswahl;
    }

    public static String getFachViewsAuswahl(int viewNummer)
    {
        return fachViewsAuswahl[viewNummer];
    }

    public static String getRaumViewsAuswahl(int viewNummer)
    {
        return raumViewsAuswahl[viewNummer];
    }

    public static ExpandableListView[] getFachViews() {
        return fachViews;
    }

    public static ExpandableListView[] getRaumViews() {
        return raumViews;
    }
}
