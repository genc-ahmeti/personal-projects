package app.com.example.genc_ahmeti.aktiehq.app;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by Genc_Ahmeti on 14.05.2017.
 */

public class VertretungCreator {

    //private Membervariablen

    public static String klasseName;
    public static String URL = "http://www.aeg-reutlingen.de/aktuelles/vertretungsplan/";

    //public Membervariablen
    public static ArrayList<String> vertretungenHeute;
    public static ArrayList<String> vertretungenMorgen;
    /*Index: allgemein: 0=Klasse, 1=Stunde, 2=Fach, 3=Lehrer, 4=Vertretung, 5=Raum, 6=Bemerkung
     * wenn entfällt: 0=Klasse, 1=Stunde, 2=Fach, 3="entfällt"
     * wenn Fach anders:
     * wenn Raum anders
     */
    public static ArrayList<ArrayList<String>> vertretungenHeuteGeteilt;
    public static ArrayList<ArrayList<String>> vertretungenMorgenGeteilt;

    // public Memberfunktionen
    public static void setKlasseName() {
        klasseName = MainActivity.getKlasseName();
    }

    public static int getKlasseZahl() {
       return Integer.parseInt(klasseName.substring(0, klasseName.indexOf(',')));
    }

    private static String getKlasseKurs() {
        return klasseName.substring(0, klasseName.indexOf(',')) + klasseName.substring(klasseName.indexOf(' ')+1);
    }

    public static String getKlasseURL() {
        switch (getKlasseZahl()) {
            case 5:
                URL += "vertretungen-klasse-5/";
                break;
            case 6:
                URL += "klasse-6/";
                break;
            case 7:
                URL += "klasse-7/";
                break;
            case 8:
                URL += "klasse-8/";
                break;
            case 9:
                URL += "klasse-9/";
                break;
            case 10:
                URL += "klasse-10/";
                break;
            case 11:
                URL += "ks1/";
                break;
            case 12:
                URL += "ks2/";
                break;
        }
        return URL;
    }

    public static ArrayList<String> getVplanText() throws IOException {
        //Verbindung mit Website von AEG Vertretungsplan: Die Seite wird als Dokument (HTML Datei)
        //in doc gespeichert
        Document doc = Jsoup.connect(getKlasseURL()).userAgent("Mozilla").get();
        ArrayList<String> vplanText = new ArrayList<String>();
        //Suche nach dem body-BLock (dort stehen die Infos zu Vertretungen)
        Element body = doc.body();
        //Suche nach den Elementen mit dem Tag <td> im body-blick (in diesen stehen die eigentlichen Vertretungen)
        Elements elmsTagTd = body.getElementsByTag("td");
        for (Element elmTagTd : elmsTagTd)
            if (Character.isLetterOrDigit(elmTagTd.text().charAt(0)))
                // System.out.println(unterelement.text()); das zeigt den Text in dem block an (wichtig)
                vplanText.add(elmTagTd.text());
        return vplanText;
    }

    public static void setVertretungen(ArrayList<String> arrList) //holt von einem Array von Strings die Informtionen über vErtretungen von einer
    // Klasse und packt sie jeweils in einen String
    {
        vertretungenHeute = new ArrayList<String>(0);
        vertretungenMorgen = new ArrayList<String>(0);
        boolean istVonEinerKlasse = false;
        boolean vertretungVonMorgen = false;
        String vertretungKlasse = "";
        for (int n = 0; n < arrList.size(); n++) {
            //Wenn "Abwesende Klassen" gefunden wird, dann weiß man, dass es das zweite mal ist; das heißt, die nachfolgenden infos zeigen vertretungen
            //für den morgigen Tag
            if (n > 3 && arrList.get(n).length() > 1 && arrList.get(n).substring(0, 2).equals("Ab"))
                vertretungVonMorgen = true;
            // Infos unter dem Klassennamen: unterschediung von morgen und heute
            if (istVonEinerKlasse) {
                vertretungKlasse += " " + arrList.get(n);
                if (vertretungVonMorgen && (n + 1 == arrList.size() || (arrList.get(n + 1).length() > 1 && arrList.get(n + 1).substring(0, Integer.toString(getKlasseZahl()).length()).equals(Integer.toString(getKlasseZahl()))))) {
                    vertretungenMorgen.add(vertretungKlasse);
                    vertretungKlasse = "";
                    istVonEinerKlasse = false;
                } else if (n + 1 == arrList.size() || (arrList.get(n + 1).length() > 1 && (arrList.get(n + 1).substring(0, Integer.toString(getKlasseZahl()).length()).equals(Integer.toString(getKlasseZahl())) || arrList.get(n + 1).substring(0, 2).equals("Ab")))) {
                    vertretungenHeute.add(vertretungKlasse);
                    vertretungKlasse = "";
                    istVonEinerKlasse = false;
                }
            }
            //Wird ausgeführt, sobald im Text des Vplans der Klassename gefunden wird -> markiert, dass die folgenden Zeilen dazugehören durch
            //istVonEinerKlasse = true;
            if (n > 3 && arrList.get(n).length() > 1 && arrList.get(n).substring(0, getKlasseKurs().length()).equals(getKlasseKurs())) {
                vertretungKlasse += " " + arrList.get(n);
                istVonEinerKlasse = true;
            }
        }
    }

    public static void setVertretungenOS(ArrayList<String> arrList) {
        vertretungenHeute = new ArrayList<String>(0);
        vertretungenMorgen = new ArrayList<String>(0);
        boolean istVonEinerKlasse = false;
        boolean vertretungVonMorgen = false;
        String vertretungKlasse = "";
        for (int n = 0; n < arrList.size(); n++) {
            //Wenn "Abwesende Klassen" gefunden wird, dann weiß man, dass es das zweite mal ist; das heißt, die nachfolgenden infos zeigen vertretungen
            //für den morgigen Tag
            if (n > 3 && arrList.get(n).length() > 1 && arrList.get(n).substring(0, 2).equals("Ab"))
                vertretungVonMorgen = true;
            // Infos unter dem Klassennamen: unterschediung von morgen und heute
            if (istVonEinerKlasse) {
                vertretungKlasse += " " + arrList.get(n);
                if (vertretungVonMorgen && (n + 1 == arrList.size() || (arrList.get(n + 1).length() > 1 && arrList.get(n + 1).substring(0, Integer.toString(getKlasseZahl()).length()).equals(Integer.toString(getKlasseZahl()))))) {
                    vertretungenMorgen.add(vertretungKlasse);
                    vertretungKlasse = "";
                    istVonEinerKlasse = false;
                } else if (n + 1 == arrList.size() || (arrList.get(n + 1).length() > 1 && (arrList.get(n + 1).substring(0, Integer.toString(getKlasseZahl()).length()).equals(Integer.toString(getKlasseZahl())) || arrList.get(n + 1).substring(0, 2).equals("Ab")))) {
                    vertretungenHeute.add(vertretungKlasse);
                    vertretungKlasse = "";
                    istVonEinerKlasse = false;
                }
            }
            //Wird ausgeführt, sobald im Text des Vplans der Klassename gefunden wird -> markiert, dass die folgenden Zeilen dazugehören durch
            //istVonEinerKlasse = true;
            if (n > 3 && arrList.get(n).length() > 1 && arrList.get(n).substring(0, Integer.toString(getKlasseZahl()).length()).equals(Integer.toString(getKlasseZahl())) && arrList.get(n).charAt(arrList.get(n).length() - 1) != '.') {
                vertretungKlasse += " " + arrList.get(n);
                istVonEinerKlasse = true;
            }
        }
    }

    public static void getVertretungen(ArrayList<String> arrList) {
        for (int n = 0; n < arrList.size(); n++)
            System.out.print("\n\n\n" + arrList.get(n));
    }

    public static void setVertretungenGeteilt() {
        //Heute
        vertretungenHeuteGeteilt = new ArrayList<ArrayList<String>>(0);
        String strGeteilt = "";
        for (int n = 0; n < vertretungenHeute.size(); n++) {
            vertretungenHeuteGeteilt.add(new ArrayList<String>());
            for (int i = 1; i < vertretungenHeute.get(n).length(); i++) {
                //Bei Leerzeichen soll das Programm den string in eine Liste in der Lise vertretungenHeuteGeteilte schreiben
                if (!Character.isWhitespace(vertretungenHeute.get(n).charAt(i))) {
                    strGeteilt += vertretungenHeute.get(n).charAt(i);
                }
                //wenn es kein leerzeciehn gibt, soll er die Buchstaben zu einem text verbinden
                if (Character.isWhitespace(vertretungenHeute.get(n).charAt(i)) || i == vertretungenHeute.get(n).length() - 1) {
                    vertretungenHeuteGeteilt.get(n).add(strGeteilt);
                    strGeteilt = "";
                }
            }
        }
        //Morgen
        vertretungenMorgenGeteilt = new ArrayList<ArrayList<String>>(0);
        strGeteilt = "";
        for (int n = 0; n < vertretungenMorgen.size(); n++) {
            vertretungenMorgenGeteilt.add(new ArrayList<String>());
            for (int i = 1; i < vertretungenMorgen.get(n).length(); i++) {
                //Bei Leerzeichen soll das Programm den string in eine Liste in der Lise vertretungenMorgenGeteilte schreiben
                if (!Character.isWhitespace(vertretungenMorgen.get(n).charAt(i))) {
                    strGeteilt += vertretungenMorgen.get(n).charAt(i);
                }
                //wenn es kein leerzeciehn gibt, soll er die Buchstaben zu einem text verbinden
                if (Character.isWhitespace(vertretungenMorgen.get(n).charAt(i)) || i == vertretungenMorgen.get(n).length() - 1) {
                    vertretungenMorgenGeteilt.get(n).add(strGeteilt);
                    strGeteilt = "";
                }
            }
        }
    }

    public static void getVertretungenGeteilt(ArrayList<ArrayList<String>> doppelArrList) {
        for (int n = 0; n < doppelArrList.size(); n++)
            for (int i = 0; i < doppelArrList.get(n).size(); i++)
                System.out.println("\n" + doppelArrList.get(n).get(i));
    }

    public static int AnzahlVertretungen(ArrayList<ArrayList<String>> doppelArrList) {
        return doppelArrList.size();
    }

    public static boolean stundeFaelltAus(ArrayList<ArrayList<String>> doppelArrList, int vertretungNr) {
        if (doppelArrList.get(vertretungNr).get(3).equals("entfällt"))
            return true;
        else
            return false;
    }
}