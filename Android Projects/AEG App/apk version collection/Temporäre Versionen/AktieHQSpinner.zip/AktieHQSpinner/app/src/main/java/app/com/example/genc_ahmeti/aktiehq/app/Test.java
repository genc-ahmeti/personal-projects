package app.com.example.genc_ahmeti.aktiehq.app;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;

public class Test extends AppCompatActivity implements AdapterView.OnItemSelectedListener  {

    Spinner[] spinners = new Spinner[1];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_layout);
        Spinner spinner = (Spinner) findViewById(R.id.custom_spinner);
        spinner.setOnItemSelectedListener(this);
        CustomAdapter customAdapter=new CustomAdapter(Test.this, spinners);
        spinner.setAdapter(customAdapter);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}