package app.com.example.genc_ahmeti.aktiehq.app;

import java.io.IOException;
import java.util.ArrayList;

import android.os.AsyncTask;

/**
 * Created by Genc_Ahmeti on 07.05.2017.
 */

public class CGI extends AsyncTask<Void, Void, Void[]> {

    //protected Memberfunktionen (für zweiten Thread)
    @Override
    protected Void[] doInBackground(Void... params) {
        VertretungCreator.setKlasseName();
        if (VertretungCreator.getKlasseZahl() <= 10) {
            try {
                VertretungCreator.setVertretungen(VertretungCreator.getVplanText());
            } catch (IOException ex) {
                //Handle IOException!!!
            }
        } else {
            try {
                VertretungCreator.setVertretungenOS(VertretungCreator.getVplanText());
            } catch (IOException ex) {
                //Handle IOException!!!
            }
        }
    return params;
    }

    @Override
    protected void onPostExecute(Void[] result) {
        VertretungCreator.setVertretungenGeteilt();


        //VERTRETUNGEN HEUTE
        int vertretungStunde;
        String str1, str2;
       //0=Klasse, 1=Stunde, 2=Fach, 3="entfällt

        /* Das istt für Testen!!!!!!!!
        if(VertretungCreator.vertretungenHeuteGeteilt.size() != 2)
        {
            VertretungCreator.vertretungenHeuteGeteilt.add(new ArrayList<String>());
        VertretungCreator.vertretungenHeuteGeteilt.get(0).add("11");
        VertretungCreator.vertretungenHeuteGeteilt.get(0).add("1.");
        VertretungCreator.vertretungenHeuteGeteilt.get(0).add("E4");
        VertretungCreator.vertretungenHeuteGeteilt.get(0).add("entfällt");
        VertretungCreator.vertretungenHeuteGeteilt.add(new ArrayList<String>());
        VertretungCreator.vertretungenHeuteGeteilt.get(1).add("11");
        VertretungCreator.vertretungenHeuteGeteilt.get(1).add("6.");
        VertretungCreator.vertretungenHeuteGeteilt.get(1).add("E4");
        VertretungCreator.vertretungenHeuteGeteilt.get(1).add("entfällt");

            VertretungCreator.vertretungenMorgenGeteilt.add(new ArrayList<String>());
            VertretungCreator.vertretungenMorgenGeteilt.get(0).add("11");
            VertretungCreator.vertretungenMorgenGeteilt.get(0).add("1.");
            VertretungCreator.vertretungenMorgenGeteilt.get(0).add("E4");
            VertretungCreator.vertretungenMorgenGeteilt.get(0).add("entfällt");
            VertretungCreator.vertretungenMorgenGeteilt.add(new ArrayList<String>());
            VertretungCreator.vertretungenMorgenGeteilt.get(1).add("11");
            VertretungCreator.vertretungenMorgenGeteilt.get(1).add("6.");
            VertretungCreator.vertretungenMorgenGeteilt.get(1).add("E4");
            VertretungCreator.vertretungenMorgenGeteilt.get(1).add("entfällt");
        }
        */
        final int ANZAHL_VERTRETUNGEN = VertretungCreator.AnzahlVertretungen(VertretungCreator.vertretungenHeuteGeteilt);
        long startTime = System.currentTimeMillis();
            // HEUTE VERTRETUNG
            for (int stunde = 0; stunde < 11; stunde++) {
                String vertretungStr = Main2Activity.getTvVertretungStrCopy(0, stunde);
                if(vertretungStr.length() == 2)
                    continue;
                str1 = vertretungStr.substring(0, vertretungStr.indexOf(','));
                for (int n = 0; n < VertretungCreator.AnzahlVertretungen(VertretungCreator.vertretungenHeuteGeteilt); n++) {
                    //Vertretung muss diese Stunde beeinflussen
                    vertretungStunde = Integer.parseInt(VertretungCreator.vertretungenHeuteGeteilt.get(n).get(1).substring(0, VertretungCreator.vertretungenHeuteGeteilt.get(n).get(1).length() - 1));
                    str2 = VertretungCreator.vertretungenHeuteGeteilt.get(n).get(2);
                    if (vertretungStunde != stunde + 1 || !str1.equals(str2))
                        continue;
                    if (VertretungCreator.stundeFaelltAus(VertretungCreator.vertretungenHeuteGeteilt, n)) {
                        Main2Activity.getTvVertretung(0, stunde).setText("Fällt aus!!!");
                        break;
                    }
            /*else if()
            else
            */
                }
            }
            // MORGEN VERTRETUNG
        int ANZAHL_VERTRETUNGEN2 = VertretungCreator.AnzahlVertretungen(VertretungCreator.vertretungenMorgenGeteilt);
        for (int stunde = 0; stunde < 11; stunde++) {
                String vertretungStr = Main2Activity.getTvVertretungStrCopy(1, stunde);
                if(vertretungStr.length() == 0)
                    continue;
                str1 = vertretungStr.substring(0, vertretungStr.indexOf(','));
                for (int n = 0; n < VertretungCreator.AnzahlVertretungen(VertretungCreator.vertretungenMorgenGeteilt); n++) {
                    //Vertretung muss diese Stunde beeinflussen
                    vertretungStunde = Integer.parseInt(VertretungCreator.vertretungenMorgenGeteilt.get(n).get(1).substring(0, VertretungCreator.vertretungenMorgenGeteilt.get(n).get(1).length() - 1));
                    str2 = VertretungCreator.vertretungenMorgenGeteilt.get(n).get(2);
                    if (vertretungStunde != stunde + 1 || !str1.equals(str2))
                        continue;
                    if (VertretungCreator.stundeFaelltAus(VertretungCreator.vertretungenMorgenGeteilt, n)) {
                        Main2Activity.getTvVertretung(1, stunde).setText("Fällt aus!!!");
                        break;
                    }
            /*else if()
            else
            */
                }
            }
    }
}