package app.com.example.genc_ahmeti.aktiehq.app;

        import android.content.Context;
        import android.os.Bundle;
        import android.support.v7.app.AppCompatActivity;
        import android.view.Menu;
        import android.view.MenuItem;
        import android.view.ViewGroup;
        import android.widget.AdapterView;
        import android.widget.Button;
        import android.view.View;
        import android.content.Intent;
        import org.joda.time.DateTime;
        import android.app.AlertDialog;
        import android.content.DialogInterface;
        import android.widget.Spinner;
        import android.widget.ArrayAdapter;
        import android.widget.TextView;

        import java.io.*;
        import java.lang.String;
        import java.lang.reflect.Array;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    // erster Index: Wochentag: 0-4 = Mo-Fr
    // zweiter Index: Stunde: 0-10 = 1.-11.
    private static String[][] stundenplan = new String[5][11];

    private static String file = "stundenplanDaten";
    private String wochentagSpinner;
    private String vorherigerWochentagSpinner = "";
    private Spinner[] fachSpinner = new Spinner[11];
    private Spinner[] raumSpinner = new Spinner[11];
    private static Spinner klasseZahlSpinner;
    private static Spinner klasseKursSpinner;
    private Spinner spinner;
    private static String klasseName;
    private static int[] wochentag = new int[2];
    private Button mBtLaunchActivity;
    private Button etFelderInitialisieren;
    private static ArrayAdapter<String> adapterOberstufe;
    private static ArrayAdapter<String> adapterMittelunterstufe;
    private ArrayAdapter<String> adapterRaum;
    private static ArrayAdapter<String> aktuellerFachAdapter;

    private boolean ListenerNurBeimErstenMalStarten = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView[] tvSchulzeiten = new TextView[11];
        for (int n = 0; n < 11; n++) {
            switch (n) {
                case 0:
                    tvSchulzeiten[n] = (TextView) findViewById(R.id.textView9);
                    break;
                case 1:
                    tvSchulzeiten[n] = (TextView) findViewById(R.id.textView10);
                    break;
                case 2:
                    tvSchulzeiten[n] = (TextView) findViewById(R.id.textView12);
                    break;
                case 3:
                    tvSchulzeiten[n] = (TextView) findViewById(R.id.textView13);
                    break;
                case 4:
                    tvSchulzeiten[n] = (TextView) findViewById(R.id.textView15);
                    break;
                case 5:
                    tvSchulzeiten[n] = (TextView) findViewById(R.id.textView16);
                    break;
                case 6:
                    tvSchulzeiten[n] = (TextView) findViewById(R.id.textView18);
                    break;
                case 7:
                    tvSchulzeiten[n] = (TextView) findViewById(R.id.textView19);
                    break;
                case 8:
                    tvSchulzeiten[n] = (TextView) findViewById(R.id.textView20);
                    break;
                case 9:
                    tvSchulzeiten[n] = (TextView) findViewById(R.id.textView21);
                    break;
                case 10:
                    tvSchulzeiten[n] = (TextView) findViewById(R.id.textView22);
                    break;
                default:
            }
        }

        for(int i = 0; i < 11; i++)
        tvSchulzeiten[i].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View viewIn) {
                for(int n = 0; n < 11; n++)
                {
                    if(viewIn == tvSchulzeiten[n]) {
                        fachSpinner[n].setSelection(aktuellerFachAdapter.getPosition(""), true);
                        raumSpinner[n].setSelection(adapterRaum.getPosition(""), true);
                        break;
                    }

                }

            }
        });


        ArrayAdapter<String> adapterKlasseZahl = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1 ) {

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {

                View v = super.getView(position, convertView, parent);
                if (position == getCount()) {
                    ((TextView)v.findViewById(android.R.id.text1)).setText("");
                    ((TextView)v.findViewById(android.R.id.text1)).setHint(getItem(getCount())); //"Hint to be displayed"
                }

                return v;
            }

            @Override
            public int getCount() {
                return super.getCount()-1; // you dont display last item. It is used as hint.
            }

        };

        adapterKlasseZahl.setDropDownViewResource(android.R.layout.simple_list_item_1);
        String[] klasseZahl = getResources().getStringArray(R.array.klasse_zahl);
        for(int n = 0; n < klasseZahl.length; n++)
            adapterKlasseZahl.add(klasseZahl[n]);
        adapterKlasseZahl.add("Klassenstufe");
        klasseZahlSpinner = (Spinner) findViewById(R.id.klasse_zahl);
        klasseZahlSpinner.setAdapter(adapterKlasseZahl);
        klasseZahlSpinner.setOnItemSelectedListener(this);

        spinner = (Spinner) findViewById(R.id.wochentage_spinner);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.wochentage_array, android.R.layout.simple_list_item_1);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
 //       spinner.setSelection(adapter.getPosition("Montag"), true);

        klasseKursSpinner = (Spinner) findViewById(R.id.klasse_kurs);







        adapterOberstufe = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1) {

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {

                View v = super.getView(position, convertView, parent);
                if (position == getCount()) {
                    ((TextView)v.findViewById(android.R.id.text1)).setText("");
                    ((TextView)v.findViewById(android.R.id.text1)).setHint(getItem(getCount())); //"Hint to be displayed"
                }

                return v;
            }

            @Override
            public int getCount() {
                return super.getCount()-1; // you dont display last item. It is used as hint.
            }

        };

        adapterOberstufe.setDropDownViewResource(android.R.layout.simple_list_item_1);
        String[] fachOberstufe = getResources().getStringArray(R.array.fach_oberstufe);
        for(int n = 0; n < fachOberstufe.length; n++)
            adapterOberstufe.add(fachOberstufe[n]);
        adapterOberstufe.add("Fach");




            adapterMittelunterstufe = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1) {

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {

                View v = super.getView(position, convertView, parent);
                if (position == getCount()) {
                    ((TextView)v.findViewById(android.R.id.text1)).setText("");
                    ((TextView)v.findViewById(android.R.id.text1)).setHint(getItem(getCount())); //"Hint to be displayed"
                }

                return v;
            }

            @Override
            public int getCount() {
                return super.getCount()-1; // you dont display last item. It is used as hint.
            }

        };

        adapterMittelunterstufe.setDropDownViewResource(android.R.layout.simple_list_item_1);
        String[] fachMittelunterstufe = getResources().getStringArray(R.array.fach_mittelunterstufe);
        for(int n = 0; n < fachMittelunterstufe.length; n++)
            adapterMittelunterstufe.add(fachMittelunterstufe[n]);
        adapterMittelunterstufe.add("Fach");





            adapterRaum = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1) {

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {

                View v = super.getView(position, convertView, parent);
                if (position == getCount()) {
                    ((TextView)v.findViewById(android.R.id.text1)).setText("");
                    ((TextView)v.findViewById(android.R.id.text1)).setHint(getItem(getCount())); //"Hint to be displayed"
                }

                return v;
            }

            @Override
            public int getCount() {
                return super.getCount()-1; // you dont display last item. It is used as hint.
            }

        };

        adapterRaum.setDropDownViewResource(android.R.layout.simple_list_item_1);
        String[] raumSchule = getResources().getStringArray(R.array.raum_schule);
        for(int n = 0; n < raumSchule.length; n++)
            adapterRaum.add(raumSchule[n]);
        adapterRaum.add("Raum");


        ArrayAdapter<String> adapterKlasseKurs = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1) {

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {

                View v = super.getView(position, convertView, parent);
                if (position == getCount()) {
                    ((TextView)v.findViewById(android.R.id.text1)).setText("");
                    ((TextView)v.findViewById(android.R.id.text1)).setHint(getItem(getCount())); //"Hint to be displayed"
                }

                return v;
            }

            @Override
            public int getCount() {
                return super.getCount()-1; // you dont display last item. It is used as hint.
            }

        };

        adapterKlasseKurs.setDropDownViewResource(android.R.layout.simple_list_item_1);
        String[] klasseKurs = getResources().getStringArray(R.array.klasse_kurs);
        for(int n = 0; n < klasseKurs.length; n++)
            adapterKlasseKurs.add(klasseKurs[n]);
        adapterKlasseKurs.add("Kurs");

        klasseKursSpinner.setAdapter(adapterKlasseKurs);


        wochentagBestimmen();
// Den Klassennamen anzeigen oben links
        try
        {
            getKlasseNameFromIS(MainActivity.this);
            klasseZahlSpinner.setSelection(adapterKlasseZahl.getPosition(klasseName.substring(0, klasseName.indexOf(','))), true);
            klasseKursSpinner.setSelection(adapterKlasseKurs.getPosition(klasseName.substring(klasseName.indexOf(' ') + 1)), true);
        }
        catch(IOException e)
        {
            klasseZahlSpinner.setSelection(adapterKlasseZahl.getPosition(getResources().getString(R.string.klasse_zahl_auswahl)), true);
        }

        for (int n = 0; n < 11; n++) {
            switch (n) {
                case 0:
                    fachSpinner[n] = (Spinner) findViewById(R.id.fach_spinner1);
                    break;
                case 1:
                    fachSpinner[n] = (Spinner) findViewById(R.id.fach_spinner2);
                    break;
                case 2:
                    fachSpinner[n] = (Spinner) findViewById(R.id.fach_spinner3);
                    break;
                case 3:
                    fachSpinner[n] = (Spinner) findViewById(R.id.fach_spinner4);
                    break;
                case 4:
                    fachSpinner[n] = (Spinner) findViewById(R.id.fach_spinner5);
                    break;
                case 5:
                    fachSpinner[n] = (Spinner) findViewById(R.id.fach_spinner6);
                    break;
                case 6:
                    fachSpinner[n] = (Spinner) findViewById(R.id.fach_spinner7);
                    break;
                case 7:
                    fachSpinner[n] = (Spinner) findViewById(R.id.fach_spinner8);
                    break;
                case 8:
                    fachSpinner[n] = (Spinner) findViewById(R.id.fach_spinner9);
                    break;
                case 9:
                    fachSpinner[n] = (Spinner) findViewById(R.id.fach_spinner10);
                    break;
                case 10:
                    fachSpinner[n] = (Spinner) findViewById(R.id.fach_spinner11);
                    break;
            }
        }

        for (int n = 0; n < 11; n++) {
            switch (n) {
                case 0:
                    raumSpinner[n] = (Spinner) findViewById(R.id.raum_spinner1);
                    break;
                case 1:
                    raumSpinner[n] = (Spinner) findViewById(R.id.raum_spinner2);
                    break;
                case 2:
                    raumSpinner[n] = (Spinner) findViewById(R.id.raum_spinner3);
                    break;
                case 3:
                    raumSpinner[n] = (Spinner) findViewById(R.id.raum_spinner4);
                    break;
                case 4:
                    raumSpinner[n] = (Spinner) findViewById(R.id.raum_spinner5);
                    break;
                case 5:
                    raumSpinner[n] = (Spinner) findViewById(R.id.raum_spinner6);
                    break;
                case 6:
                    raumSpinner[n] = (Spinner) findViewById(R.id.raum_spinner7);
                    break;
                case 7:
                    raumSpinner[n] = (Spinner) findViewById(R.id.raum_spinner8);
                    break;
                case 8:
                    raumSpinner[n] = (Spinner) findViewById(R.id.raum_spinner9);
                    break;
                case 9:
                    raumSpinner[n] = (Spinner) findViewById(R.id.raum_spinner10);
                    break;
                case 10:
                    raumSpinner[n] = (Spinner) findViewById(R.id.raum_spinner11);
                    break;
            }
        }

    for(int n = 0; n < 11; n++)
        {
            fachSpinner[n].setAdapter(adapterMittelunterstufe);
            raumSpinner[n].setAdapter(adapterRaum);
        }

        //Wenn im internal Storage schon frühere Stundenpläne vorhanden:
       try
        {
            getStundenplanFromIS(MainActivity.this);
            getKlasseNameFromIS(MainActivity.this);

            String klassenstufe = klasseName.substring(0, klasseName.indexOf(','));

            if(klassenstufe.equals("Klassenstufe") || Integer.parseInt(klassenstufe) < 11)
                aktuellerFachAdapter = adapterMittelunterstufe;
            else
                aktuellerFachAdapter = adapterOberstufe;

            for(int n = 0; n < 11; n++)
            {
                fachSpinner[n].setAdapter(aktuellerFachAdapter);
            }
        }
        catch(IOException e)
        {
            aktuellerFachAdapter = adapterMittelunterstufe;
            for(int n = 0; n < 11; n++)
            {
                fachSpinner[n].setAdapter(aktuellerFachAdapter);
            }
            klasseZahlSpinner.setSelection(adapterKlasseZahl.getCount());
            klasseKursSpinner.setSelection(adapterKlasseKurs.getCount());
            for(int n = 0; n < 11; n++)
            {
                fachSpinner[n].setSelection(adapterMittelunterstufe.getCount());
                raumSpinner[n].setSelection(adapterRaum.getCount());
            }
            AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
            alertDialog.setMessage("Gespeicherter Stundenplan konnte nicht gefunden werden. Bitte neu machen!");
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            alertDialog.show();
        }

        // Button, um zu den Vertretungen zu kommen
        mBtLaunchActivity = (Button) findViewById(R.id.bt_launch_activity);
        mBtLaunchActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
Intent myIntent = null;
                try {
                    getStundenplanFromIS(MainActivity.this);
                    getKlasseNameFromIS(MainActivity.this);

                    String fehlendeStunde = stundeKorrektEingegeben();
                    String fehlendeKlasse = klassennameKorrektEingegeben();
                    if (MainActivity.stundenplanEingegeben(MainActivity.this)) {
                        if (fehlendeStunde.equals("")) {
                            if(fehlendeKlasse.equals(""))
                            {MainActivity.wochentagBestimmen();
                                myIntent = new Intent(MainActivity.this, Main2Activity.class);}
                            else {
                                AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
                                alertDialog.setMessage(fehlendeKlasse);
                                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                        new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int which) {
                                                dialog.dismiss();
                                            }
                                        });
                                alertDialog.show();
                            }
                        } else {
                            AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
                            alertDialog.setMessage(fehlendeStunde);
                            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                        }
                                    });
                            alertDialog.show();
                        }
                    }
                }
                catch(IOException e) {
                    AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
                    alertDialog.setMessage("Gespeicherter Stundenplan konnte nicht gefunden werden. Bitte neu machen!");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }
                if(myIntent != null)
                    startActivity(myIntent);
                    }
        });

        // Button, um die Einträge zu speichern
        etFelderInitialisieren = (Button) findViewById(R.id.et_felder_initialisieren);
        etFelderInitialisieren.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                        for(int stunde = 0; stunde < 11; stunde++)
                        {
                            switch(wochentagSpinner.substring(0, 2))
                            {
                                case "Mo": stundenplan[0][stunde] = fachSpinner[stunde].getSelectedItem().toString()+", "+raumSpinner[stunde].getSelectedItem().toString();
                                    break;
                                case "Di": stundenplan[1][stunde] = fachSpinner[stunde].getSelectedItem().toString()+", "+raumSpinner[stunde].getSelectedItem().toString();
                                    break;
                                case "Mi": stundenplan[2][stunde] = fachSpinner[stunde].getSelectedItem().toString()+", "+raumSpinner[stunde].getSelectedItem().toString();
                                    break;
                                case "Do": stundenplan[3][stunde] = fachSpinner[stunde].getSelectedItem().toString()+", "+raumSpinner[stunde].getSelectedItem().toString();
                                    break;
                                case "Fr": stundenplan[4][stunde] = fachSpinner[stunde].getSelectedItem().toString()+", "+raumSpinner[stunde].getSelectedItem().toString();
                                    break;
                            }
                        }
                String[][] aa = stundenplan;
                if(stundenplanEingegeben(MainActivity.this))
                {
                // das ist für den Klassennammen
            klasseName = klasseZahlSpinner.getSelectedItem().toString() + ", " + klasseKursSpinner.getSelectedItem().toString();
                       try{
                            setKlasseNameInIS();
                        } catch (IOException e) {
                            AlertDialog alertDialog2 = new AlertDialog.Builder(MainActivity.this).create();
                            alertDialog2.setMessage("Klassenname konnte nicht gespeichert werden!");
                            alertDialog2.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                        }
                                    });
                            alertDialog2.show();

                        }

                try {
                        // hier für Fächer und räume des Stundenplans
                        setStundenplanInIS();
                    }
                    catch(IOException e) {
                    AlertDialog alertDialog2 = new AlertDialog.Builder(MainActivity.this).create();
                    alertDialog2.setMessage("Stundenplan konnte nicht gespeichert werden!");
                    alertDialog2.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog2.show();
                }
            }

            }
        });
    }

    public static String getKlasseName()
    {
        return klasseName;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if (id == R.id.action_settings) {

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void launchActivity() {

        Intent intent = new Intent(this, Main2Activity.class);
        startActivity(intent);
    }

    public static String getStundenplan(int wochentag, int stunde)
    {
    return stundenplan[wochentag][stunde];
    }

    public static int getWochentag(int heuteOderMorgen) {
        switch (heuteOderMorgen) {
            case 0:
                return wochentag[0];
            case 1:
                return wochentag[1];
            default:
                return -1;
        }
    }

    public void onItemSelected(AdapterView<?> parent, View view,
                               int pos, long id) {
        // An item was selected. You can retrieve the selected item using
        // parent.getItemAtPosition(pos)
        if(parent == spinner) {
            wochentagSpinner = parent.getItemAtPosition(pos).toString();
            if (vorherigerWochentagSpinner.equals(""))
                vorherigerWochentagSpinner = wochentagSpinner;
            if (!vorherigerWochentagSpinner.equals(wochentagSpinner)) {
                for (int stunde = 0; stunde < 11; stunde++) {
                    stundenplan[getWochentag(vorherigerWochentagSpinner.substring(0, 2))][stunde] = fachSpinner[stunde].getSelectedItem().toString() + ", " + raumSpinner[stunde].getSelectedItem().toString();

                }
                vorherigerWochentagSpinner = wochentagSpinner;
            }
            String[][] aaa = stundenplan;
            for (int stunde = 0; stunde < 11; stunde++) {
                if (stundenplan[getWochentag(wochentagSpinner.substring(0, 2))][stunde] != null)
                {
                    if (istImAdapterVorhanden(aktuellerFachAdapter, getStundenplan(getWochentag(wochentagSpinner.substring(0, 2)), stunde).substring(0, getStundenplan(getWochentag(wochentagSpinner.substring(0, 2)), stunde).indexOf(','))))
                        fachSpinner[stunde].setSelection(aktuellerFachAdapter.getPosition(getStundenplan(getWochentag(wochentagSpinner.substring(0, 2)), stunde).substring(0, getStundenplan(getWochentag(wochentagSpinner.substring(0, 2)), stunde).indexOf(','))), true);
                    else
                        fachSpinner[stunde].setSelection(aktuellerFachAdapter.getPosition("Fach"), true);

                    if(getStundenplan(getWochentag(wochentagSpinner.substring(0, 2)), stunde).indexOf(',') + 1 == getStundenplan(getWochentag(wochentagSpinner.substring(0, 2)), stunde).length() - 1)
                        raumSpinner[stunde].setSelection(adapterRaum.getPosition(""), true);
                    else
                        raumSpinner[stunde].setSelection(adapterRaum.getPosition(getStundenplan(getWochentag(wochentagSpinner.substring(0, 2)), stunde).substring(getStundenplan(getWochentag(wochentagSpinner.substring(0, 2)), stunde).indexOf(',') + 2)), true);
                }
                else {
                    fachSpinner[stunde].setSelection(aktuellerFachAdapter.getPosition("Fach"), true);
                    raumSpinner[stunde].setSelection(adapterRaum.getPosition("Raum"), true);
                }
            }
            String[][] aa = stundenplan;
        }
        else if(!ListenerNurBeimErstenMalStarten)
            ListenerNurBeimErstenMalStarten = true;
        else
        {

            String wochentag = spinner.getSelectedItem().toString();
            for (int stunde = 0; stunde < 11; stunde++)
                stundenplan[getWochentag(wochentag.substring(0, 2))][stunde] = fachSpinner[stunde].getSelectedItem().toString() + ", " + raumSpinner[stunde].getSelectedItem().toString();
                String klasseZahlSpinner = parent.getItemAtPosition(pos).toString();
            if(klasseZahlSpinner.equals("Klassenstufe") || Integer.parseInt(klasseZahlSpinner) < 11)
                MainActivity.setAktuellerFachAdapter(MainActivity.getAdapterMittelunterstufe());
            else
                MainActivity.setAktuellerFachAdapter(MainActivity.getAdapterOberstufe());
            for(int n = 0; n < 11; n++)
            {
                fachSpinner[n].setAdapter(aktuellerFachAdapter);
            }
           // spinner.setSelection(adapter.getPosition(getStundenplan(getWochentag(wochentagSpinner.substring(0, 2)), stunde).substring(0, getStundenplan(getWochentag(wochentagSpinner.substring(0, 2)), stunde).indexOf(','))), true);
            for (int stunde = 0; stunde < 11; stunde++) {
                if (stundenplan[getWochentag(wochentag.substring(0, 2))][stunde] != null) {
                    String[][] aa = stundenplan;
                    String a = getStundenplan(getWochentag(wochentag.substring(0, 2)), stunde);
                    String b = a.substring(0, getStundenplan(getWochentag(wochentag.substring(0, 2)), stunde).indexOf(','));
                    if (istImAdapterVorhanden(aktuellerFachAdapter, getStundenplan(getWochentag(wochentag.substring(0, 2)), stunde).substring(0, getStundenplan(getWochentag(wochentag.substring(0, 2)), stunde).indexOf(','))))
                        fachSpinner[stunde].setSelection(aktuellerFachAdapter.getPosition(getStundenplan(getWochentag(wochentag.substring(0, 2)), stunde).substring(0, getStundenplan(getWochentag(wochentag.substring(0, 2)), stunde).indexOf(','))), true);
                    else
                        fachSpinner[stunde].setSelection(aktuellerFachAdapter.getPosition("Fach"), true);

                    if (getStundenplan(getWochentag(wochentag.substring(0, 2)), stunde).indexOf(',') + 1 != getStundenplan(getWochentag(wochentag.substring(0, 2)), stunde).length() - 1)
                        raumSpinner[stunde].setSelection(adapterRaum.getPosition(getStundenplan(getWochentag(wochentag.substring(0, 2)), stunde).substring(getStundenplan(getWochentag(wochentag.substring(0, 2)), stunde).indexOf(',') + 2)), true);
                    else
                        raumSpinner[stunde].setSelection(adapterRaum.getPosition("Raum"), true);
                } else {
                    fachSpinner[stunde].setSelection(aktuellerFachAdapter.getPosition("Fach"), true);
                    raumSpinner[stunde].setSelection(adapterRaum.getPosition("Raum"), true);
                }
            }
        }
        }


    public void onNothingSelected(AdapterView<?> parent) {
        // Another interface callback
    }

    public static void getStundenplanFromIS(Context context) throws IOException
    {
        String[][] a = stundenplan;
        FileInputStream fIn = context.openFileInput(file);
        int varMo = 0, varDi = 0, varMi = 0, varDo = 0, varFr = 0;
        String wochentag;
        int c;
        boolean erstesLeerzeichenWarDa = false;
        StringBuilder temp = new StringBuilder("");
        while( (c = fIn.read()) != -1)
        {
            if((char) c != ' ')
                temp.append((char) c);
            if(((char) c == ' ' && erstesLeerzeichenWarDa) || ((char) c == ' ' && !erstesLeerzeichenWarDa) && temp.toString().length() == 3)
            {
                erstesLeerzeichenWarDa = false;
                wochentag = temp.toString().substring(0, 2);
                switch(wochentag)
                {
                    case "Mo":
                        if(temp.toString().length() > 3)
                            stundenplan[0][varMo++] = temp.toString().substring(3);
                        else
                            stundenplan[0][varMo++] = "";
                        break;
                    case "Di": if(temp.toString().length() > 3)
                        stundenplan[1][varDi++] = temp.toString().substring(3);
                    else
                        stundenplan[1][varDi++] = "";
                        break;
                    case "Mi": if(temp.toString().length() > 3)
                        stundenplan[2][varMi++] = temp.toString().substring(3);
                    else
                        stundenplan[2][varMi++] = "";
                        break;
                    case "Do": if(temp.toString().length() > 3)
                        stundenplan[3][varDo++] = temp.toString().substring(3);
                    else
                        stundenplan[3][varDo++] = "";
                        break;
                    case "Fr": if(temp.toString().length() > 3)
                        stundenplan[4][varFr++] = temp.toString().substring(3);
                    else
                        stundenplan[4][varFr++] = "";
                        break;
                }
                temp.setLength(0);
                temp.trimToSize();
                continue;
            }

            if((char) c == ' ' && !erstesLeerzeichenWarDa)
            {
                erstesLeerzeichenWarDa = true;
                temp.append((char) c);
            }


        }
        String[][] aa = stundenplan;
    }

    public void setKlasseNameInIS() throws IOException
    {
        FileOutputStream fOut = openFileOutput("klasseNameIS",MODE_PRIVATE);
        // erst die Klasse
        fOut.write(getKlasseName().getBytes());
    }

    public static void getKlasseNameFromIS(Context context) throws IOException
    {
        FileInputStream fIn = context.openFileInput("klasseNameIS");

        int c;
        StringBuilder temp = new StringBuilder("");
        while( (c = fIn.read()) != -1) {
            temp.append((char) c);
        }
        klasseName = temp.toString();
    }

    public void setStundenplanInIS() throws IOException
    {
        FileOutputStream fOut = openFileOutput(file,MODE_PRIVATE);

        // jetzt kommen die Fächer
        for(int wochentag = 0; wochentag < 5; wochentag++)
            for(int stunde = 0; stunde < 11; stunde++)
            {
                switch(wochentag)
                {
                    case 0: fOut.write("Mo:".getBytes()); break;
                    case 1: fOut.write("Di:".getBytes()); break;
                    case 2: fOut.write("Mi:".getBytes()); break;
                    case 3: fOut.write("Do:".getBytes()); break;
                    case 4: fOut.write("Fr:".getBytes()); break;
                }
                fOut.write((stundenplan[wochentag][stunde] + " ").getBytes());
            }
        fOut.close();
    }

    private int getWochentag(String wochentagPräfix)
    {
        switch(wochentagPräfix)
        {
            case "Mo":
                return 0;
            case "Di":
                return 1;
            case "Mi":
                return 2;
            case "Do":
                return 3;
            case "Fr":
                return 4;
        }
        return -1;
    }

    public static boolean stundenplanEingegeben(Context context)
    {
        String strWochentag = "";
        for(int wochentag = 0; wochentag < 5; wochentag++)
            for(int stunde = 0; stunde < 11; stunde++)
                if(stundenplan[wochentag][stunde] == null) {
                    switch(wochentag)
                    {
                        case 0:
                            strWochentag += "Montag wurde nicht eingetragen und gespeichert!";
                            break;
                        case 1:
                            strWochentag += "Dienstag wurde nicht eingetragen und gespeichert!";
                            break;
                        case 2:
                            strWochentag += "Mittwoch wurde nicht eingetragen und gespeichert!";
                            break;
                        case 3:
                            strWochentag += "Donnerstag wurde nicht eingetragen und gespeichert!";
                            break;
                        case 4:
                            strWochentag += "Freitag wurde nicht eingetragen und gespeichert!";
                            break;
                    }
                    AlertDialog alertDialog = new AlertDialog.Builder(context).create();
                    alertDialog.setMessage(strWochentag);
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                    return false;
                }
        return true;
    }

    public static void wochentagBestimmen()
    {
        //Bestimmung von heutigem/morgigem Tag bezüglich der Vertretungen
        //wenn samstag, sonntag heute: heuteVertretung:Montag, morgenVertretung:Montag

        //Tag der Woche, von 1-7, Mo-So
        int dayOfWeek = new DateTime().getDayOfWeek();

        if (dayOfWeek == 6 || dayOfWeek == 7) {
            wochentag[0] = 1;
            wochentag[1] = 1;
        } else if (dayOfWeek == 5) {
            wochentag[0] = 5;
            wochentag[1] = 1;
        } else {
            wochentag[0] = dayOfWeek;
            wochentag[1] = wochentag[0] + 1;
        }
    }

    public static String stundeKorrektEingegeben() {
        String tag = "";
        for(int wochentag = 0; wochentag < 5; wochentag++) {
            switch(wochentag) {
                case 0: tag = "Montag"; break;
                case 1: tag = "Dienstag"; break;
                case 2: tag = "Mittwoch"; break;
                case 3: tag = "Donnerstag"; break;
                case 4: tag = "Freitag"; break;
            }

            for (int stunde = 0; stunde < 11; stunde++) {
                String stunden = stundenplan[wochentag][stunde];
                if(stunden.length() == 2)
                    continue;
              //  if(stunden.equals("Fach, Raum"))
                //    return "Die " + Integer.toString(stunde+1) + ". Stunde am " + tag + "ist gar nicht eingetragen!";
                if((stunden.substring(0, stunden.indexOf(',')).equals("Fach")
                        && !stunden.substring(stunden.indexOf(' ')+1).equals("Raum"))
                    || (!stunden.substring(0, stunden.indexOf(',')).equals("Fach")
                        && stunden.substring(stunden.indexOf(' ')+1).equals("Raum")))
                    return "Die " + Integer.toString(stunde+1) + ". Stunde am " + tag + " ist unvollständig eingetragen.";
                if (stundenplan[wochentag][stunde].indexOf(',') == 0 || stundenplan[wochentag][stunde].indexOf(' ') == stundenplan[wochentag][stunde].length()-1)
                    return "Die " + Integer.toString(stunde+1) + ". Stunde am " + tag + " ist unvollständig eingetragen.";
            }
        }
        return "";
    }

    public boolean istImAdapterVorhanden(ArrayAdapter<String> arrayAdapter,String str) {
return arrayAdapter.getPosition(str) != -1;
    }

    public static String klassennameKorrektEingegeben()
    {
        if(klasseName.equals("Klassenstufe, Kurs"))
            return "Klassenstufe und Kurs müssen angegeben werden!";
        if((klasseName.substring(0, klasseName.indexOf(',')).equals("Klassenstufe")
                && !klasseName.substring(klasseName.indexOf(' ')+1).equals("Kurs"))
                || (!klasseName.substring(0, klasseName.indexOf(',')).equals("Klassenstufe")
                && klasseName.substring(klasseName.indexOf(' ')+1).equals("Kurs")))
                    return "Klassenname unvollständig. Bitte neu eingeben!";
            if (Integer.parseInt(klasseName.substring(0, klasseName.indexOf(','))) > 10 && Character.isLetter(klasseName.charAt(klasseName.length() - 1)))
                return "Die Kurswahl (a-e) ist nicht für die Kursstufe gedacht!";
            if (Integer.parseInt(klasseName.substring(0, klasseName.indexOf(','))) < 11 && Character.isDigit(klasseName.charAt(klasseName.length() - 1)))
                return "Die Kurswahl (1-5) ist nur für die Kursstufe gedacht!";

            return "";
    }

    public static void setAktuellerFachAdapter(ArrayAdapter<String> arrayAdapter)
    {
        aktuellerFachAdapter = arrayAdapter;
    }

    public static ArrayAdapter<String> getAdapterOberstufe()
    {
        return adapterOberstufe;
    }

    public static ArrayAdapter<String> getAdapterMittelunterstufe()
    {
        return adapterMittelunterstufe;
    }
}