package app.com.example.genc_ahmeti.aktiehq.app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Spinner;

public class CustomAdapter extends BaseAdapter {

    Context context;
    Spinner[] spinners;
    LayoutInflater inflter;

    public CustomAdapter(Context applicationContext, Spinner[] spinnersInput) {
        this.context = applicationContext;
        this.spinners = spinnersInput;
        inflter = (LayoutInflater.from(applicationContext));
    }

    @Override
    public int getCount() {
        return spinners.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup)
    {
        view = inflter.inflate(R.layout.custom_spinner_items, null);
        Spinner spin = (Spinner) view.findViewById(R.id.custom_spinner_items);
        switch(i)
        {
            case 0: ArrayAdapter<CharSequence> arrayAdapter = ArrayAdapter.createFromResource(context,
                    R.array.fach_oberstufe_D, android.R.layout.simple_list_item_1);
                spin.setAdapter(arrayAdapter);
                break;
            default:
        }
        return view;
    }
}