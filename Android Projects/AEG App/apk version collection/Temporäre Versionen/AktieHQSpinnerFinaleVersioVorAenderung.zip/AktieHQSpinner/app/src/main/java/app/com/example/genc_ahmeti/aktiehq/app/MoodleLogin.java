package app.com.example.genc_ahmeti.aktiehq.app;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.jsoup.Jsoup;

public class MoodleLogin extends AppCompatActivity {

    private WebView myWebView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.moodle_login_layout);
        myWebView = (WebView) findViewById(R.id.webview);
        myWebView.setWebViewClient(new Callback());
        CookieManager.getInstance().setAcceptCookie(true);


        String html = "<!DOCTYPE html>\n" +
                "<html\n" +
                "<body>\n" +
                "<form action=\"https://www.aeg-reutlingen.de/moodle2/login/index.php\" method=\"post\" name=\"form\" id=\"form\">\n" +
                "<p><input type=\"text\" name=\"username\" id=\"user\" size=\"15\" /></p>\n" +
                "<p><input type=\"password\" name=\"password\" id=\"pass\" size=\"15\" /></p>\n" +
                "<p><input type=\"submit\" name=\"Submit\" id=\"sub\" value=\"Login\" disabled=\"disabled\" /></p>\n" +
                "<p><input type=\"button\" name=\"check\" value=\"Anmeldedaten überprüfen\" onClick=\"httpRequest()\" /></p>\n" +
                "</form>\n" +
                "<script>\n" +
                "    function httpRequest(){\n" +
                "        var ende = false;\n" +
                "       var benutzername = document.getElementById(\"user\").value;\n" +
                "   var passwort = document.getElementById(\"pass\").value;\n" +
                "    var xmlHttp = new XMLHttpRequest();\n" +
                "    xmlHttp.onreadystatechange = function() \n" +
                "    { \n" +
                "        if (xmlHttp.readyState == 4 && xmlHttp.status == 200)\n" +
                "          {\n" +
                "              if(xmlHttp.responseText.substr(2,5) === \"token\")\n" +
                "              {\n" +
                "                  document.getElementById(\"sub\").disabled = false;\n" +
                "                  alert(\"Die Anmeldedaten stimmen!\");\n" +
                "                  ende = true;\n" +
                "                  return;\n" +
                "              }\n" +
                "              else if(!ende)\n" +
                "              {\n" +
                "                  alert(\"Die Anmeldedaten stimmen nicht!\");\n" +
                "                  ende = true;\n" +
                "                  return;\n" +
                "              }\n" +
                "              \n" +
                "          }\n" +
                "    }       \n" +
                "setTimeout(function(){if(!ende){alert(\"Die Anmeldedaten stimmen nicht!\"); ende=true;return;}}, 2000);\n" +
                "    xmlHttp.open(\"GET\", \"https://www.aeg-reutlingen.de/moodle2/login/token.php?username=\"+benutzername+\"&password=\"+passwort+\"&service=moodle_mobile_app\", true); // true for asynchronous \n" +
                "    xmlHttp.send(null);\n" +
                "   }\n" +
                "</script>\n" +
                "</body>\n" +
                "</html>\n";/*" <!DOCTYPE html>\n" +
                "<html\n" +
                "<body>\n" +
                "<form action=\"https://www.aeg-reutlingen.de/moodle2/login/index.php\" method=\"post\" name=\"form\" id=\"form\">\n" +
                "  <p><input type=\"text\" name=\"username\" size=\"15\" /></p>\n" +
                "  <p><input type=\"password\" name=\"password\" size=\"15\" /></p>\n" +
                "  <p><input type=\"submit\" name=\"Submit\" value=\"Login\" /></p>\n" +
                "</form>" +
                "" +
                "\n" +
                "</body>\n" +
                "</html> ";*/
        if (savedInstanceState != null) {
            myWebView.restoreState(savedInstanceState);
        } else
            try {
                WebSettings settings = myWebView.getSettings();
                settings.setDefaultTextEncodingName("utf-8");
                settings.setJavaScriptEnabled(true);
                myWebView.setWebChromeClient(new WebChromeClient());
                settings.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
                myWebView.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
            } catch (Exception e) {
                String aa = "a";
            }

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        myWebView.saveState(outState);
    }

    private class Callback extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return (false);
        }
    }
}
