package app.com.example.genc_ahmeti.aktiehq.app;

import android.app.Activity;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;

public class Test extends AppCompatActivity implements AdapterView.OnItemSelectedListener  {

    private Spinner spinner;
    private Spinner spinnerKlasse;

    private ArrayAdapter<String> adapterFachMittelunterstufe;
    private ArrayAdapter<String> adapterFachOberstufe;
    private ArrayAdapter<String> adapterRaum;
    private ArrayAdapter<String> adapterKlasse;

    private ArrayList<String> arrList;

    private boolean schalter2 = false;

    private String fachInhalt;
    private String klasseInhalt;

    private int fachCounter = 1;

    private PopupWindow popupWindow1 = null;
    private View popupView1 = null;
    private PopupWindow popupWindow2 = null;
    private View popupView2 = null;
    private boolean wasDismissedWithoutClickingOnItem = true;
    private boolean fachOkGedrückt = false;
    private boolean klasseOkGedrückt = false;
    private boolean schalter = false;

    private String selectedItem = null;

    private ArrayAdapter<String> popupAdapterFach = null;
    private ArrayAdapter<String> popupAdapterRaum= null;
    private ArrayAdapter<String> popupAdapterKlasse= null;

    private Spinner popupFachSpinnerFach = null;
    private Spinner popupFachSpinnerRaum= null;
    private Spinner popupKlasseSpinner= null;

    private Button popupFachButton = null;
    private Button popupKlasseButton = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_layout);

        spinner = (Spinner) findViewById(R.id.custom_spinner);
        spinnerKlasse = (Spinner) findViewById(R.id.custom_spinner2);

        fachInhalt = getResources().getString(R.string.fach_auswahl);
        klasseInhalt = getResources().getString(R.string.klasse_auswahl);

        arrList = new ArrayList<String>(Arrays.asList(getResources().getStringArray(R.array.fach_oberstufe)));


        adapterFachOberstufe = new ArrayAdapter<String>(Test.this, android.R.layout.simple_list_item_1, arrList) {

            @Override
            public int getCount() {
                return super.getCount()-wieVieleSpinnerItemsVersteckenFachOberstufe(); // you dont display last item. It is used as hint.
            }

        };
        adapterFachOberstufe.setDropDownViewResource(android.R.layout.simple_list_item_1);
               spinner.setAdapter(adapterFachOberstufe);
              spinner.setOnItemSelectedListener(this);
               spinner.setSelection(adapterFachOberstufe.getPosition(getResources().getString(R.string.fach_auswahl)));

        adapterKlasse = new ArrayAdapter<String>(Test.this, android.R.layout.simple_list_item_1, arrayListKopie(getResources().getStringArray(R.array.klasse))) {

            @Override
            public int getCount() {
                return super.getCount()-wieVieleSpinnerItemsVersteckenKlasse(); // you dont display last item. It is used as hint.
            }

        };
        adapterKlasse.setDropDownViewResource(android.R.layout.simple_list_item_1);
        spinnerKlasse.setAdapter(adapterKlasse);
        spinnerKlasse.setOnItemSelectedListener(this);
        spinnerKlasse.setSelection(adapterKlasse.getPosition(getResources().getString(R.string.klasse_auswahl)));
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long l) {
       if (parent != null) {
            if (schalter2 && parent.getSelectedItem().equals(""))
                {
                       schalter2 = false;
                     spinner.setSelection(adapterFachOberstufe.getPosition(fachInhalt));
                }
            else if (parent == spinner && position == arrList.size()-1)
                spinner.setSelection(adapterFachOberstufe.getPosition(fachInhalt));
                else
                {
                    selectedItem = parent.getItemAtPosition(position).toString();
                    if (popupWindow1 == null || popupWindow2 == null) {
                    LayoutInflater layoutInflater = (LayoutInflater) getBaseContext().getSystemService(LAYOUT_INFLATER_SERVICE);
                    popupView1 = layoutInflater.inflate(R.layout.popup_fach, null);
                    popupWindow1 = new PopupWindow(popupView1, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
                    popupView2 = layoutInflater.inflate(R.layout.popup_klasse, null);
                    popupWindow2 = new PopupWindow(popupView2, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
                }
                // popup fach
                popupFachSpinnerFach = (Spinner) popupView1.findViewById(R.id.popup_spinner_fach);
                popupFachSpinnerRaum = (Spinner) popupView1.findViewById(R.id.popup_spinner_raum);
                popupFachButton = (Button) popupView1.findViewById(R.id.popup_button_fach);
                popupFachButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String str1 = popupFachSpinnerFach.getSelectedItem().toString();
                        String str2 = popupFachSpinnerRaum.getSelectedItem().toString();

                        if (!str1.equals(getResources().getString(R.string.fach_auswahl)) && !str2.equals(getResources().getString(R.string.raum_auswahl))) {
                            String erg = str1 + ", " + str2;
                            if (adapterFachOberstufe.getPosition(erg) == -1) {
                                arrList.remove(adapterFachOberstufe.getPosition(fachInhalt));
                                arrList.add(erg);
                                adapterFachOberstufe.notifyDataSetChanged();
                            }
                            fachInhalt = erg;
                            spinner.setSelection(adapterFachOberstufe.getPosition(erg), true);
                            fachOkGedrückt = true;
                            schalter2 = true;
                            popupWindow1.dismiss();
                        }
                    }
                });

                // popup klasse
                popupKlasseSpinner = (Spinner) popupView2.findViewById(R.id.popup_spinner_klasse);
                popupKlasseButton = (Button) popupView2.findViewById(R.id.popup_button_klasse);
                popupKlasseButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        String str = popupKlasseSpinner.getSelectedItem().toString();
                        klasseInhalt = str;
                        spinnerKlasse.setSelection(adapterKlasse.getPosition(str), true);
                        klasseOkGedrückt = true;
                        popupWindow2.dismiss();

                    }
                });

                switch (selectedItem) {
                    case "": fachInhalt = ""; break;
                    // -------------------------------------- KLASSEN ----------------------------------------
                    case "5":
                        popupAdapterKlasse = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.klasse_5)));
                        break;
                    case "6":
                        popupAdapterKlasse = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.klasse_6)));
                        break;
                    case "7":
                        popupAdapterKlasse = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.klasse_7)));
                        break;
                    case "8":
                        popupAdapterKlasse = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.klasse_8)));
                        break;
                    case "9":
                        popupAdapterKlasse = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.klasse_9)));
                        break;
                    case "10":
                        popupAdapterKlasse = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.klasse_10)));
                        break;
                    case "11":
                        popupAdapterKlasse = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.klasse_11)));
                        break;
                    case "12":
                        popupAdapterKlasse = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.klasse_12)));
                        break;
                    // --------------------------------------- RÄUME -------------------------------------------
                    case "000":
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum_000)));
                        ((Spinner) parent).setAdapter(popupAdapterRaum);
                        break;
                    case "100":
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum_100)));
                        ((Spinner) parent).setAdapter(popupAdapterRaum);
                        break;
                    case "200":
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum_200)));
                        ((Spinner) parent).setAdapter(popupAdapterRaum);
                        break;
                    case "300":
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum_300)));
                        ((Spinner) parent).setAdapter(popupAdapterRaum);
                        break;
                    case "ch":
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum_ch)));
                        ((Spinner) parent).setAdapter(popupAdapterRaum);
                        break;
                    case "ph":
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum_ph)));
                        ((Spinner) parent).setAdapter(popupAdapterRaum);
                        break;
                    case "bio":
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum_bio)));
                        ((Spinner) parent).setAdapter(popupAdapterRaum);
                        break;
                    case "bk":
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum_bk)));
                        ((Spinner) parent).setAdapter(popupAdapterRaum);
                        break;
                    case "com":
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum_com)));
                        ((Spinner) parent).setAdapter(popupAdapterRaum);
                        break;
                    case "s":
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum_s)));
                        ((Spinner) parent).setAdapter(popupAdapterRaum);
                        break;
                    case "N":
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum_N)));
                        ((Spinner) parent).setAdapter(popupAdapterRaum);
                        break;
                    // ---------------------------------------- FÄCHER --------------------------------------
                    case "D":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_D)));
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum)));
                        break;
                    case "M":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_M)));
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum)));
                        break;
                    case "E":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_E)));
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum)));
                        break;
                    case "F":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_F)));
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum)));
                        break;
                    case "Ph:":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_Ph)));
                        ((Spinner) parent).setAdapter(popupAdapterFach);
                        break;
                    case "ph:":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_ph)));
                        ((Spinner) parent).setAdapter(popupAdapterFach);
                        break;
                    case "Ph":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_Ph_oder_ph)));
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum)));
                        break;
                    case "Ch:":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_Ch)));
                        ((Spinner) parent).setAdapter(popupAdapterFach);
                    case "ch:":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_ch)));
                        ((Spinner) parent).setAdapter(popupAdapterFach);
                    case "Ch":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_Ch_oder_ch)));
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum)));
                        break;
                    case "G:":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_G)));
                        ((Spinner) parent).setAdapter(popupAdapterFach);
                    case "g:":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_g)));
                        ((Spinner) parent).setAdapter(popupAdapterFach);
                    case "G":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_G_oder_g)));
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum)));
                        break;
                    case "Ek:":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_Ek)));
                        ((Spinner) parent).setAdapter(popupAdapterFach);
                    case "ek:":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_ek)));
                        ((Spinner) parent).setAdapter(popupAdapterFach);
                    case "Ek":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_Ek_oder_ek)));
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum)));
                        break;
                    case "Bk:":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_Bk)));
                        ((Spinner) parent).setAdapter(popupAdapterFach);
                    case "bk:":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_bk)));
                        ((Spinner) parent).setAdapter(popupAdapterFach);
                    case "Bk":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_Bk_oder_bk)));
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum)));
                        break;
                    case "eth":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_eth)));
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum)));
                        break;
                    case "kRel":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_kRel)));
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum)));
                        break;
                    case "S:":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_S)));
                        ((Spinner) parent).setAdapter(popupAdapterFach);
                    case "s:":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_s)));
                        ((Spinner) parent).setAdapter(popupAdapterFach);
                    case "S":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_S_oder_s)));
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum)));
                        break;
                    case "inf":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_inf)));
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum)));
                        break;
                    case "vkm":
                        popupAdapterFach = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.fach_oberstufe_vkm)));
                        popupAdapterRaum = new ArrayAdapter<String>(Test.this, android.R.layout.simple_spinner_item, arrayListKopie(getResources().getStringArray(R.array.raum)));
                        break;
                    default:
                }

                switch (selectedItem) {
                    // ------------------------------- FÄCHER MIT 4-/2-STÜNDIGE VARIANTE ----------------------------
                    case "Ph":
                    case "Ch":
                    case "G":
                    case "Ek":
                    case "Bk":
                    case "S":
                        // ------------------------------- FÄCHER OHNE 4-/2-STÜNDIGE VARIANTE ----------------------------
                    case "D":
                    case "M":
                    case "E":
                    case "F":
                    case "eth":
                    case "kRel":
                    case "inf":
                    case "vkm":

                        popupAdapterFach.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        popupAdapterRaum.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                        popupFachSpinnerFach.setAdapter(popupAdapterFach);
                        popupFachSpinnerRaum.setAdapter(popupAdapterRaum);

                        popupFachSpinnerFach.setOnItemSelectedListener(this);
                        popupFachSpinnerRaum.setOnItemSelectedListener(this);

                        popupWindow1.setBackgroundDrawable(new ColorDrawable(getResources().getColor(android.R.color.transparent)));
                        popupWindow1.setOutsideTouchable(true);
                        popupWindow1.setFocusable(true);
                        popupWindow1.showAsDropDown(view, 50, -30);
                        popupWindow1.setOnDismissListener(new PopupWindow.OnDismissListener() {
                            @Override
                            public void onDismiss() {
                                if (!fachOkGedrückt)
                                    spinner.setSelection(adapterFachOberstufe.getPosition(fachInhalt), true);
                                else
                                    fachOkGedrückt = false;
                            }
                        });
                        break;
                    // -------------------------------------- KLASSEN ----------------------------------------
                    case "5":
                    case "6":
                    case "7":
                    case "8":
                    case "9":
                    case "10":
                    case "11":
                    case "12":

                        popupAdapterKlasse.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                        popupKlasseSpinner.setAdapter(popupAdapterKlasse);

                        popupKlasseSpinner.setOnItemSelectedListener(Test.this);

                        popupWindow2.setBackgroundDrawable(new ColorDrawable(getResources().getColor(android.R.color.transparent)));
                        popupWindow2.setOutsideTouchable(true);
                        popupWindow2.setFocusable(true);
                        popupWindow2.showAsDropDown(view, 50, -30);
                        popupWindow2.setOnDismissListener(new PopupWindow.OnDismissListener() {
                            @Override
                            public void onDismiss() {
                                if (!klasseOkGedrückt)
                                    spinnerKlasse.setSelection(adapterKlasse.getPosition(klasseInhalt), true);
                                else
                                    klasseOkGedrückt = false;
                            }
                        });
                        break;

                    default: // dient nur zum Abfangen von D1,D2, Kurs, Fach,......
                }
            }
        }
    }


    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    public int wieVieleSpinnerItemsVersteckenFachOberstufe () {
// Hint + Leer
        int anzahlZuVersteckenderItems = 1;
        return anzahlZuVersteckenderItems;
    }

    public int wieVieleSpinnerItemsVersteckenKlasse() {
// Hint + Leer
        int anzahlZuVersteckenderItems = 1;
        anzahlZuVersteckenderItems += getResources().getStringArray(R.array.klasse_5).length;
        anzahlZuVersteckenderItems += getResources().getStringArray(R.array.klasse_6).length;
        anzahlZuVersteckenderItems += getResources().getStringArray(R.array.klasse_7).length;
        anzahlZuVersteckenderItems += getResources().getStringArray(R.array.klasse_8).length;
        anzahlZuVersteckenderItems += getResources().getStringArray(R.array.klasse_9).length;
        anzahlZuVersteckenderItems += getResources().getStringArray(R.array.klasse_10).length;
        anzahlZuVersteckenderItems += getResources().getStringArray(R.array.klasse_11).length;
        anzahlZuVersteckenderItems += getResources().getStringArray(R.array.klasse_12).length;

        return anzahlZuVersteckenderItems;
    }

    public ArrayList<String> arrayListKopie (String[] arrStr)
    {
        ArrayList<String> arrList = new ArrayList<>(arrStr.length);
        for(int n = 0; n < arrStr.length; n++)
            arrList.add(arrStr[n]);
        return arrList;
    }
}


