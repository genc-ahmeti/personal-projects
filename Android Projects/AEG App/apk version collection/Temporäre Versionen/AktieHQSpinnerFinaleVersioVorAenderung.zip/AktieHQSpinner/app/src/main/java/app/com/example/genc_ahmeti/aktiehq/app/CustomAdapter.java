package app.com.example.genc_ahmeti.aktiehq.app;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Spinner;

public class CustomAdapter extends BaseAdapter implements AdapterView.OnItemSelectedListener {

    Context context;
    Spinner[] spinners;
    LayoutInflater inflter;

    public CustomAdapter(Context applicationContext,Spinner[] spinnersInput) {

            try {
                this.context = applicationContext;
                this.spinners = spinnersInput;
                //inflter = (LayoutInflater.from(applicationContext));
                this.inflter = LayoutInflater.from(applicationContext);
            } catch (WindowManager.BadTokenException e) {
                String a = "";
            }
    }

    @Override
    public int getCount() {
            try {
                return spinners.length;
            } catch (WindowManager.BadTokenException e) {
                String a = "";
                return spinners.length;
            }
    }

    @Override
    public Object getItem(int i) {

            try {
                return null;
            } catch (WindowManager.BadTokenException e) {
                String a = "";
                return null;
            }
    }


    @Override
    public long getItemId(int i) {
            try {
                return 0;
            } catch (WindowManager.BadTokenException e) {
                String a = "";
                return 0;
            }
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (context != null &&!((Activity) context).isFinishing()) {
            try {
                if (view == null)
                    view = inflter.inflate(R.layout.custom_spinner_items, null);

                Spinner spin = (Spinner) view.findViewById(R.id.custom_spinner_items);
                switch (i) {
                    case 0:
                        if (!((Activity) context).isFinishing()) {
                            ArrayAdapter<CharSequence> arrayAdapter = ArrayAdapter.createFromResource(context,
                                    R.array.fach_oberstufe_D, android.R.layout.simple_list_item_1);
                            arrayAdapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
                            spin.setAdapter(arrayAdapter);
                            spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                    String a = "";
                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> parent) {

                                }
                            });
                            break;
                        }
                    case 1:
                        if (!((Activity) context).isFinishing()) {
                            ArrayAdapter<CharSequence> arrayAdapter2 = ArrayAdapter.createFromResource(context,
                                    R.array.fach_oberstufe_M, android.R.layout.simple_list_item_1);
                            arrayAdapter2.setDropDownViewResource(android.R.layout.simple_list_item_1);
                            spin.setAdapter(arrayAdapter2);
                            spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                    String a = "";
                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> parent) {

                                }
                            });
                            break;
                        }
                    default:
                }
                return view;
            } catch (WindowManager.BadTokenException e) {
                String a = "";
                return null;
            }
        }
        return null;
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}