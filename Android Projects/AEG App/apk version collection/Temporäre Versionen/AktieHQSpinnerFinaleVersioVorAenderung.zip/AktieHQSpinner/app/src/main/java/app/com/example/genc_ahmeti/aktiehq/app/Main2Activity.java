package app.com.example.genc_ahmeti.aktiehq.app;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.Calendar;

public class Main2Activity extends AppCompatActivity {

    private Button mBtGoBack;

    private Button btnAktualisieren;
    private static TextView tvHeuteStunde[];
    private static TextView tvMorgenStunde[];
    private static String[] tvHeuteStundeStrCopy;
    private static String[] tvMorgenStundeStrCopy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        mBtGoBack = (Button) findViewById(R.id.bt_go_back);
        mBtGoBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        tvHeuteStunde = new TextView[11];
        tvMorgenStunde = new TextView[11];
        tvHeuteStundeStrCopy = new String[11];
        tvMorgenStundeStrCopy = new String[11];

        for (int n = 0; n < 11; n++) {
            switch (n) {
                case 0:
                    tvHeuteStunde[n] = (TextView) findViewById(R.id.textHeuteStunde1);
                    tvHeuteStunde[n].setText(MainActivity.getStundenplan(MainActivity.getWochentag(0) - 1, 0));
                    tvHeuteStundeStrCopy[n] = tvHeuteStunde[n].getText().toString();
                    tvMorgenStunde[n] = (TextView) findViewById(R.id.textMorgenStunde1);
                    tvMorgenStunde[n].setText(MainActivity.getStundenplan(MainActivity.getWochentag(1) - 1, 0));
                    tvMorgenStundeStrCopy[n] = tvMorgenStunde[n].getText().toString();
                    break;
                case 1:
                    tvHeuteStunde[n] = (TextView) findViewById(R.id.textHeuteStunde2);
                    tvHeuteStunde[n].setText(MainActivity.getStundenplan(MainActivity.getWochentag(0) - 1, 1));
                    tvHeuteStundeStrCopy[n] = tvHeuteStunde[n].getText().toString();
                    tvMorgenStunde[n] = (TextView) findViewById(R.id.textMorgenStunde2);
                    tvMorgenStunde[n].setText(MainActivity.getStundenplan(MainActivity.getWochentag(1) - 1, 1));
                    tvMorgenStundeStrCopy[n] = tvMorgenStunde[n].getText().toString();
                    break;
                case 2:
                    tvHeuteStunde[n] = (TextView) findViewById(R.id.textHeuteStunde3);
                    tvHeuteStunde[n].setText(MainActivity.getStundenplan(MainActivity.getWochentag(0) - 1, 2));
                    tvHeuteStundeStrCopy[n] = tvHeuteStunde[n].getText().toString();
                    tvMorgenStunde[n] = (TextView) findViewById(R.id.textMorgenStunde3);
                    tvMorgenStunde[n].setText(MainActivity.getStundenplan(MainActivity.getWochentag(1) - 1, 2));
                    tvMorgenStundeStrCopy[n] = tvMorgenStunde[n].getText().toString();
                    break;
                case 3:
                    tvHeuteStunde[n] = (TextView) findViewById(R.id.textHeuteStunde4);
                    tvHeuteStunde[n].setText(MainActivity.getStundenplan(MainActivity.getWochentag(0) - 1, 3));
                    tvHeuteStundeStrCopy[n] = tvHeuteStunde[n].getText().toString();
                    tvMorgenStunde[n] = (TextView) findViewById(R.id.textMorgenStunde4);
                    tvMorgenStunde[n].setText(MainActivity.getStundenplan(MainActivity.getWochentag(1) - 1, 3));
                    tvMorgenStundeStrCopy[n] = tvMorgenStunde[n].getText().toString();
                    break;
                case 4:
                    tvHeuteStunde[n] = (TextView) findViewById(R.id.textHeuteStunde5);
                    tvHeuteStunde[n].setText(MainActivity.getStundenplan(MainActivity.getWochentag(0) - 1, 4));
                    tvHeuteStundeStrCopy[n] = tvHeuteStunde[n].getText().toString();
                    tvMorgenStunde[n] = (TextView) findViewById(R.id.textMorgenStunde5);
                    tvMorgenStunde[n].setText(MainActivity.getStundenplan(MainActivity.getWochentag(1) - 1, 4));
                    tvMorgenStundeStrCopy[n] = tvMorgenStunde[n].getText().toString();
                    break;
                case 5:
                    tvHeuteStunde[n] = (TextView) findViewById(R.id.textHeuteStunde6);
                    tvHeuteStunde[n].setText(MainActivity.getStundenplan(MainActivity.getWochentag(0) - 1, 5));
                    tvHeuteStundeStrCopy[n] = tvHeuteStunde[n].getText().toString();
                    tvMorgenStunde[n] = (TextView) findViewById(R.id.textMorgenStunde6);
                    tvMorgenStunde[n].setText(MainActivity.getStundenplan(MainActivity.getWochentag(1) - 1, 5));
                    tvMorgenStundeStrCopy[n] = tvMorgenStunde[n].getText().toString();
                    break;
                case 6:
                    tvHeuteStunde[n] = (TextView) findViewById(R.id.textHeuteStunde7);
                    tvHeuteStunde[n].setText(MainActivity.getStundenplan(MainActivity.getWochentag(0) - 1, 6));
                    tvHeuteStundeStrCopy[n] = tvHeuteStunde[n].getText().toString();
                    tvMorgenStunde[n] = (TextView) findViewById(R.id.textMorgenStunde7);
                    tvMorgenStunde[n].setText(MainActivity.getStundenplan(MainActivity.getWochentag(1) - 1, 6));
                    tvMorgenStundeStrCopy[n] = tvMorgenStunde[n].getText().toString();
                    break;
                case 7:
                    tvHeuteStunde[n] = (TextView) findViewById(R.id.textHeuteStunde8);
                    tvHeuteStunde[n].setText(MainActivity.getStundenplan(MainActivity.getWochentag(0) - 1, 7));
                    tvHeuteStundeStrCopy[n] = tvHeuteStunde[n].getText().toString();
                    tvMorgenStunde[n] = (TextView) findViewById(R.id.textMorgenStunde8);
                    tvMorgenStunde[n].setText(MainActivity.getStundenplan(MainActivity.getWochentag(1) - 1, 7));
                    tvMorgenStundeStrCopy[n] = tvMorgenStunde[n].getText().toString();
                    break;
                case 8:
                    tvHeuteStunde[n] = (TextView) findViewById(R.id.textHeuteStunde9);
                    tvHeuteStunde[n].setText(MainActivity.getStundenplan(MainActivity.getWochentag(0) - 1, 8));
                    tvHeuteStundeStrCopy[n] = tvHeuteStunde[n].getText().toString();
                    tvMorgenStunde[n] = (TextView) findViewById(R.id.textMorgenStunde9);
                    tvMorgenStunde[n].setText(MainActivity.getStundenplan(MainActivity.getWochentag(1) - 1, 8));
                    tvMorgenStundeStrCopy[n] = tvMorgenStunde[n].getText().toString();
                    break;
                case 9:
                    tvHeuteStunde[n] = (TextView) findViewById(R.id.textHeuteStunde10);
                    tvHeuteStunde[n].setText(MainActivity.getStundenplan(MainActivity.getWochentag(0) - 1, 9));
                    tvHeuteStundeStrCopy[n] = tvHeuteStunde[n].getText().toString();
                    tvMorgenStunde[n] = (TextView) findViewById(R.id.textMorgenStunde10);
                    tvMorgenStunde[n].setText(MainActivity.getStundenplan(MainActivity.getWochentag(1) - 1, 9));
                    tvMorgenStundeStrCopy[n] = tvMorgenStunde[n].getText().toString();
                    break;
                case 10:
                    tvHeuteStunde[n] = (TextView) findViewById(R.id.textHeuteStunde11);
                    tvHeuteStunde[n].setText(MainActivity.getStundenplan(MainActivity.getWochentag(0) - 1, 10));
                    tvHeuteStundeStrCopy[n] = tvHeuteStunde[n].getText().toString();
                    tvMorgenStunde[n] = (TextView) findViewById(R.id.textMorgenStunde11);
                    tvMorgenStunde[n].setText(MainActivity.getStundenplan(MainActivity.getWochentag(1) - 1, 10));
                    tvMorgenStundeStrCopy[n] = tvMorgenStunde[n].getText().toString();
                    break;
            }
        }

            btnAktualisieren = new Button(Main2Activity.this);
            btnAktualisieren = (Button) findViewById(R.id.btnAktualisieren);
            btnAktualisieren.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    new CGI().execute();
                }
            });
        }

    public static TextView getTvVertretung(int morgenOderHeute, int stunde) {
        TextView tv = null;
        switch (morgenOderHeute) {
            case 0:
                tv = tvHeuteStunde[stunde];
                break;
            case 1:
                tv = tvMorgenStunde[stunde];
                break;
        }
        return tv;
    }

    public static String getTvVertretungStrCopy(int morgenOderHeute, int stunde) {
        String str = null;
        switch (morgenOderHeute) {
            case 0:
                str = tvHeuteStundeStrCopy[stunde];
                break;
            case 1:
                str = tvMorgenStundeStrCopy[stunde];
                break;
        }
        return str;
    }
}
