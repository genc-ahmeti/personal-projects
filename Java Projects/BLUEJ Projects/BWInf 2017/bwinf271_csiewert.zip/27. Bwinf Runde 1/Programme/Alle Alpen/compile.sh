g++ -lglut main.cpp -o bin/alpen.bin
