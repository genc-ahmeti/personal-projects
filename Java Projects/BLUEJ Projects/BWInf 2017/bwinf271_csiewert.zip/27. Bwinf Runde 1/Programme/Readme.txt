Zum Kompilieren der Programme PizzaVision und Tankomatik benötigst
du die aktuellen GTK+ Header. Zum Kompileren von "Alle Alpen" werden
die OpenGL Header (Glut oder Freeglut) benötigt.


mfg,

Christian Siewert
